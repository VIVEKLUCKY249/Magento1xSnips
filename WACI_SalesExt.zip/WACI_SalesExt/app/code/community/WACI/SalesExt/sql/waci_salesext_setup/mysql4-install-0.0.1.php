<?php
$installer = $this;
$installer->startSetup();
$installer->addAttribute('order', 'dynamics_ord', array(
			    'type'              =>'varchar',
			    'visible'           => true,
			    'required'          => false,
			    'is_user_defined'   => false,
			    'note'              => 'Dynamics ORD')
			);
$installer->getConnection()->addColumn($installer->getTable('sales_flat_order'), 'dynamics_ord','VARCHAR(255) NULL DEFAULT NULL');
$installer->getConnection()->addColumn($installer->getTable('sales_flat_order_grid'), 'dynamics_ord','VARCHAR(255) NULL DEFAULT NULL');
$installer->endSetup();