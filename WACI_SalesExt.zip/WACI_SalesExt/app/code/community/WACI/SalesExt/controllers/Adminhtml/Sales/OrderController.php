<?php
include_once Mage::getModuleDir('controllers', 'Mage_Adminhtml') . DS . 'Sales' . DS . 'OrderController.php';
class WACI_SalesExt_Adminhtml_Sales_OrderController extends Mage_Adminhtml_Sales_OrderController
{
    public function editordAction()
    {
        $postData = $this->getRequest()->getPost();
        Mage::log('WACI_SalesExt_Adminhtml_Sales_OrderController::ordEditAction'.print_r($postData, true) );
        $id = $this->getRequest()->getParam('order_id');
        $order = Mage::getModel('sales/order')->load($id);
        $order->setDynamicsOrd($postData['dynamics_ord']);
        $order->save();
        $this->_getSession()->addSuccess(Mage::helper('sales')->__('Dynamics ORD has been updated successfully!!!'));
        // return to sales_order view
        Mage::app()->getResponse()->setRedirect(Mage::helper('adminhtml')->getUrl("adminhtml/sales_order/view", array('order_id'=> $id)));
    }
}