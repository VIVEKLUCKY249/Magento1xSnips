<?php
/*$listCats = array("Kaffe",
				"Utstyr",
				"S�tt og godt",
				"Te",
				"VismaGlobal_import",
				"Trashcan",
				"Hidden");*/
$listCats = array("Aromatisert kaffe",
"Cup of Excellence",
"Espresso kaffe",
"Segafredo espresso",
"Single estate / origin",
"Spesialblandinger kaffe",
"Sesongprodukter kaffe",
"Julekaffe 2015",
"P�skekaffe");
$parent_path = false;

$mageFilename = 'app/Mage.php';
require_once $mageFilename;
Mage::setIsDeveloperMode(true);
ini_set('display_errors', 1);
umask(0);
Mage::app('admin');
Mage::register('isSecureArea', 1);
$parentId = '31';
foreach($listCats as $catName):
 try{
    $category = Mage::getModel('catalog/category');
    $category->setName($catName);
    $category->setUrlKey(strtolower($catName));
    $category->setIsActive(1);
    $category->setDisplayMode('PRODUCTS');
    $category->setIsAnchor(1); //for active anchor
    $category->setStoreId(Mage::app()->getStore()->getId());
    $parentCategory = Mage::getModel('catalog/category')->load($parentId);
    $category->setPath($parentCategory->getPath());
    $category->save();
    echo "Category ".$catName." created successfully!!!<br/><br/>";
} catch(Exception $e) {
    print_r($e);
}
endforeach;
