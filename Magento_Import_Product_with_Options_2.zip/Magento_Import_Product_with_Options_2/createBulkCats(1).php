<?php
$listCats = array("Bajonettmaskiner",
"Jura",
"Kaffe-/ Espressokverner",
"Kaffetrakter / Vannkoker",
"Renseutstyr",
"Kanner",
"Beger og lokk",
"Beholdere og bokser",
"Diverse",
"Espressoutstyr",
"Kopper og krus",
"Poser",
"Sesongprodukter",
"Sowden Softbrew",
"Tesiler/Tefilter",
"Litteratur og kursmaterial",
"Juleting, gaver og utstyr 2015",
"Forlife",
"Bialetti",
"Glass",
"Jura tilbeh�r",
"Chemex",
"Hario",
"Bambuskopper",
"La Cafeti�re Presskanner");

$parent_path = false;

$mageFilename = 'app/Mage.php';
require_once $mageFilename;
Mage::setIsDeveloperMode(true);
ini_set('display_errors', 1);
umask(0);
Mage::app('admin');
Mage::register('isSecureArea', 1);
$parentId = '32';
foreach($listCats as $catName):
 try{
    $category = Mage::getModel('catalog/category');
    $category->setName($catName);
    $category->setUrlKey(strtolower($catName));
    $category->setIsActive(1);
    $category->setDisplayMode('PRODUCTS');
    $category->setIsAnchor(1); //for active anchor
    $category->setStoreId(Mage::app()->getStore()->getId());
    $parentCategory = Mage::getModel('catalog/category')->load($parentId);
    $category->setPath($parentCategory->getPath());
    $category->save();
    echo "Category ".$catName." created successfully!!!<br/><br/>";
} catch(Exception $e) {
    print_r($e);
}
endforeach;
