<?php
error_reporting(E_ALL);
require_once 'app/Mage.php';
umask(0);
Mage::app('default');
/*$category = Mage::getModel('catalog/category');
$catTree = $category->getTreeModel()->load();
$catIds = $catTree->getCollection()->getAllIds();
$cats = array();
if ($catIds){
    foreach ($catIds as $id){
        $cat = Mage::getModel('catalog/category');
        $cat->load($id);
        $cats[$cat->getId()] = $cat->getName();
    }
}
echo "<pre/>";print_r($cats);die;*/
$defaultCategoryId = Mage::app()->getStore($storeId)->getRootCategoryId();
$categories = Mage::getModel('catalog/category')
					->getCollection()
					->addAttributeToSelect('*')
					->addAttributeToFilter('parent_id', array('neq' => 0))
					->setStoreId(1)
					->load();
$i = 0;
foreach ($categories as $category)
{
    if ($category->getIsActive()) {
		$catArr[$i]['id'] = $category->getId();
		#$catArr[]['name'] = $category->getName()."--".$category->getUrlKey();
		$catArr[$i]['name'] = $category->getName();
        $entity_id = $category->getId();
        $name = $category->getName();
        $url_key = $category->getUrlKey();
        $url_path = $category->getUrl();
        $i++;
    }
}
function array2csv(array &$array)
{
   if (count($array) == 0) {
     return null;
   }
   ob_start();
   $df = fopen("php://output", 'w');
   fputcsv($df, array_keys(reset($array)));
   foreach ($array as $row) {
      fputcsv($df, $row);
   }
   fclose($df);
   return ob_get_clean();
}
#$_categories = array_unique(array_map(function ($i) { return $i['name']; }, $_categories));
function download_send_headers($filename) {
    // disable caching
    $now = gmdate("D, d M Y H:i:s");
    header("Expires: Tue, 03 Jul 2001 06:00:00 GMT");
    header("Cache-Control: max-age=0, no-cache, must-revalidate, proxy-revalidate");
    header("Last-Modified: {$now} GMT");
    // force download
    header("Content-Type: application/force-download");
    header("Content-Type: application/octet-stream");
    header("Content-Type: application/download");
    // disposition / encoding on response body
    header("Content-Disposition: attachment;filename={$filename}");
    header("Content-Transfer-Encoding: binary");
}
#download_send_headers("data_export_" . date("Y-m-d") . ".csv");
download_send_headers("Categories.csv");
echo array2csv($catArr);
#exit("Categories exported to csv!!!");
die();
