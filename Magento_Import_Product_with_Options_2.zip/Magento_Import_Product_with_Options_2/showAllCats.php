<?php
$mageFilename = 'app/Mage.php';
require_once $mageFilename;
Mage::setIsDeveloperMode(true);
ini_set('display_errors', 1);
umask(0);
Mage::app('admin');
Mage::register('isSecureArea', 1);

#$myrootcats = array('12,15,18,20');
$myrootcats = array('2');
$catArray = array();
foreach ($myrootcats as $_rootCat)
{
    $children = Mage::getModel('catalog/category')->getCategories($_rootCat);
    foreach ($children as $category)
    {
      if($category->getIsActive()){
        $catArray[] = $category->getId();
      } 
    }
    $catArray[] = $_rootCat;
}
array_unique($catArray);
echo "<pre/>";print_r($catArray);die;
