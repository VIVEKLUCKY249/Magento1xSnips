<?php
require_once 'app/Mage.php';
Mage::app(1);

$rootCatId = Mage::app()->getStore()->getRootCategoryId();
$csvCatArr = array();

$_category = Mage::getModel('catalog/category');
$treeModel = $_category->getTreeModel();
$treeModel->load();
$allIds = $treeModel->getCollection()->getAllIds();
$catCollection = Mage::getModel('catalog/category')->getCollection()->addAttributeToSelect('*');
$catCollection->getSelect()->distinct(true);
$_categories = array();
if ($allIds)
{
foreach ($allIds as $id)
{
$_category->load($id);
if(!in_array($_category->getName(), $_categories)):
	$_categories[$id]['Id'] = $_category->getId();
	$_categories[$id]['name'] = $_category->getName();
endif;
#$_categories[$id]['path'] = $_category->getPath();
}
/*foreach ($allIds as $Id)
{
$path = explode('/', $_categories[$Id]['path']);
$string = '';
foreach ($path as $pathId)
{
$string.= $_categories[$pathId]['name'] . ' >';
$cnt++;
}
$_string.= ';' . $Id ."\n";
#echo $_string;
}*/
#echo "<pre/>";print_r($_categories);die;

function array2csv(array &$array)
{
   if (count($array) == 0) {
     return null;
   }
   ob_start();
   $df = fopen("php://output", 'w');
   fputcsv($df, array_keys(reset($array)));
   foreach ($array as $row) {
      fputcsv($df, $row);
   }
   fclose($df);
   return ob_get_clean();
}
$_categories = array_unique(array_map(function ($i) { return $i['name']; }, $_categories));
$newCatArr = array();
$i = 0;
foreach($_categories as $key => $val):
	/*if(is_int($key)) $newCatArr[]['id'] = $key;
	if(is_string($val)) $newCatArr[]['name'] = $val;*/
	$newCatArr[$i]['id'] = $key;$newCatArr[$i]['name'] = $val;
	$i++;
endforeach;
function download_send_headers($filename) {
    // disable caching
    $now = gmdate("D, d M Y H:i:s");
    header("Expires: Tue, 03 Jul 2001 06:00:00 GMT");
    header("Cache-Control: max-age=0, no-cache, must-revalidate, proxy-revalidate");
    header("Last-Modified: {$now} GMT");

    // force download  
    header("Content-Type: application/force-download");
    header("Content-Type: application/octet-stream");
    header("Content-Type: application/download");

    // disposition / encoding on response body
    header("Content-Disposition: attachment;filename={$filename}");
    header("Content-Transfer-Encoding: binary");
}

#download_send_headers("data_export_" . date("Y-m-d") . ".csv");
download_send_headers("Categories.csv");
echo array2csv($newCatArr);
#exit("Categories exported to csv!!!");
die();

}
