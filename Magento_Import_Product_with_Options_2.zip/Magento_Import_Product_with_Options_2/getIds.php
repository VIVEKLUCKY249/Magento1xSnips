<?php
error_reporting(E_ALL);
require_once './app/Mage.php';
umask(0);
Mage::app('admin');

$allCats11 = getAllCatsArr();
#echo "<pre/>";print_r($allCats11);
$file = 'categories1.csv';
$fileData = fopen($file,'r');
$i = 0;

$fp = file('categories1.csv');
#echo count($fp);
$newCsvIds = '';
while($row = fgets($fileData)) {
	// can parse further $row by usingstr_getcsv
	#echo $row.'<br/>';
	$new = '';
	if($i > 0) {
		$row = str_replace('"', '',$row);
		$row = trim($row);
		$cats = explode(",", $row);
		#echo "<pre/>";print_r($cats);die;
		$k = 0;
		foreach($cats as $cat):
			#if (array_key_exists($cat, $allCats11)) {
			if($k < count($cats)-1)
				$new .= $allCats11[$cat].",";
			else
				$new .= $allCats11[$cat];
			$k++;
				//echo $allCats11[$cat];
			#}
		endforeach;
		$newCsvIds .= '"'.$new.'"'."\n\r";
	}
	$i++;
}


function getAllCatsArr() {
$defaultCategoryId = Mage::app()->getStore($storeId)->getRootCategoryId();
$categories = Mage::getModel('catalog/category')
					->getCollection()
					->addAttributeToSelect('*')
					->addAttributeToFilter('parent_id', array('neq' => 0))
					->setStoreId(1)
					->load();
$j = 0;
foreach ($categories as $category)
{
    if ($category->getIsActive()) {
		$catArr[$category->getName()] = $category->getId();
        $j++;
    }
}
return $catArr;
}

download_send_headers("Category_Ids.csv");
echo $newCsvIds;
function download_send_headers($filename) {
    // disable caching
    $now = gmdate("D, d M Y H:i:s");
    header("Expires: Tue, 03 Jul 2001 06:00:00 GMT");
    header("Cache-Control: max-age=0, no-cache, must-revalidate, proxy-revalidate");
    header("Last-Modified: {$now} GMT");

    // force download  
    header("Content-Type: application/force-download");
    header("Content-Type: application/octet-stream");
    header("Content-Type: text/csv");
    header("Content-Type: application/download");

    // disposition / encoding on response body
    header("Content-Disposition: attachment;filename={$filename}");
    header("Content-Transfer-Encoding: binary");
}
