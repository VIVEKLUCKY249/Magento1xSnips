<?php
/**
 * Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@magentocommerce.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade Magento to newer
 * versions in the future. If you wish to customize Magento for your
 * needs please refer to http://www.magentocommerce.com for more information.
 *
 * @category    Mage
 * @package     Mage_Sales
 * @copyright   Copyright (c) 2014 Magento Inc. (http://www.magentocommerce.com)
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */


/**
 * Sales report invoiced collection
 *
 * @category    Mage
 * @package     Mage_Sales
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_Sales_Model_Resource_Report_Invoiced_Collection_Invoiced
    extends Mage_Sales_Model_Resource_Report_Invoiced_Collection_Order
{
    /**
     * Initialize custom resource model
     *
     */
    public function __construct()
    {
        parent::_construct();
        $this->setModel('adminhtml/report_item');
        $this->_resource = Mage::getResourceModel('sales/report')->init('sales/invoiced_aggregated');
        $this->setConnection($this->getResource()->getReadConnection());
    }
    
    /**
	 * For debugging only remove after debugging process done
	 */
	# Function to debug collections which can't be debugged the usual way, starts:
	## Add below function is collection class itself, $this = collection object
	public function _afterLoad() {
		$selectSql = $this->getSelect()->__toString();
		$this->_doLog($selectSql);
		$rowsPerSql = $this->count();
		$items = $this->getItems();
		return parent::_afterLoad();
	}
	## This magic method is called automatically by Magento system.
	# Function to debug collections which can't be debugged the usual way, ends....
	
	// Function for logging into any log file start:
	/// Add below function to class you're working in.
	private function _doLog($logline, $filename = null)
	{
		$logDir = Mage::getBaseDir('log');
		if(is_null($filename)) $fh = fopen($logDir."/CollectionData.log", "a");
		else $fh = fopen($logDir."/$filename", "a+");
		if(is_array($logline) || is_object($logline)) {
			ob_start();
			echo "<pre/>";print_r($logline);
			$logline = ob_get_clean();
		}
		if($fh) {
			fwrite($fh, "[".date("d.m.Y h:i:s")."] ".$logline."\n");
			fclose($fh);
		}
	}
	// Function for logging into any log file finish....
}
