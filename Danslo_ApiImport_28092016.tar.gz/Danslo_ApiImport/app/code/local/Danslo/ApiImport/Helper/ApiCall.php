<?php
class Danslo_ApiImport_Helper_ApiCall extends Mage_Core_Helper_Abstract
{
	#https://api.cin7.com/cloud/APILite/APILite.ashx?apiid=49711&apikey=ycXFYUfL0MK3BULZ3RpcFDkBX96y51Cl&action=GetProductOptions
    private $_url = "https://api.cin7.com/cloud/APILite/APILite.ashx";
    private $_apiId = 49711;
    private $_apiKey = "ycXFYUfL0MK3BULZ3RpcFDkBX96y51Cl";
    private $_function = null;
    private $_fields = null;
    private $_filter = null;
    private $_orderby = null;
    
    protected function getUrl()
    {
        $url = $this->_url;
        if($this->_fields != "*") $queryString = "apiid=".$this->_apiId."&apikey=".$this->_apiKey."&action=".$this->_function."&fields=".$this->_fields;
        else $queryString = "apiid=".$this->_apiId."&apikey=".$this->_apiKey."&action=".$this->_function;
        $queryString .= $this->_filter.$this->_orderby;        
        $finalUrl = $url."?".$queryString;
        Mage::log(print_r($finalUrl, true),NULL, 'finalUrl.log');
        return $finalUrl;
    }
    protected function _setAction($functionName) {
		return $this->_function = $functionName;
	}
	protected function _setFilter($where) {
		return $this->_filter = "&where=".$where;
	}
	protected function _setOrderBy($orderby) {
		return $this->_orderby = "&orderby=".$orderby;
	}
	protected function _setFields($fields) {
		if(count($fields) > 0) {
			$this->_fields = $this->_arrToCsv($fields);
		} else $this->_fields = "*";
		Mage::log(print_r($this->_fields, true),NULL, 'requiredFields.log');
		return true;
	}
    public function callCin7Api($actionName, $where = null, $orderby = null, $fields = array()) {
		self::_setAction($actionName);
		self::_setFields($fields);
		self::_setFilter($where);
		self::_setOrderBy($orderby);
		return $this->_call();
	}
    protected function _call()
    {
        if ($curl = curl_init()) {
            $result = false;
            $result = file_get_contents($this->getUrl());
            $myfile = fopen("productOptions.csv", "a+") or die("Unable to open file!");
			fwrite($myfile, print_r($result,true));
			fclose($myfile);			
            return $result;
        }
        return false;
    }
    protected function parseResult($response, &$curl)
    {
        try {
            $info = curl_getinfo($curl);
            $code = $info['http_code'];
            switch ($code) {
                case 401:
                    throw new Exception('The API Key was missing or invalid');
                    break;
                case 500:
                    throw new Exception('An unhandled exception occured on the server');
                    break;
            }
            $data = Mage::helper('core')->jsonDecode($response);
            if (isset($data['ErrorCode'])) {
                throw new Exception($data['Message'], $data['ErrorCode']);
            }
            return $data;
        } catch (Exception $e) {
            $this->_errorCode    = $e->getCode();
            $this->_errorMessage = $e->getMessage();
        }
        curl_close($curl);
        return false;
    }
    public function csv2AssocArray($filePath, $keyPointer = null) {
		$array = $fields = array(); $i = 0;
		$handle = @fopen($filePath, "r");
		if ($handle) {
			while (($row = fgetcsv($handle, 4096)) !== false) {
				if (empty($fields)) {
					$fields = $row;
					continue;
				}
				foreach ($row as $key => $value) {
					#$array[$i][$fields[$key]] = $value;
					if($keyPointer === null) $array[$row[0]][$fields[$key]] = $value;
					else $array[$row[$keyPointer]][$fields[$key]] = $value;
				}
				$i++;
			}
			if (!feof($handle)) {
				echo "Error: unexpected fgets() fail\n";
			}
			fclose($handle);
		}
		return $array;
	}
	protected function _array2Csv($data) {
		# Generate CSV data from array
		$fh = fopen('php://temp', 'rw'); # don't create a file, attempt to use memory instead
		# write out the headers
		fputcsv($fh, array_keys(current($data)));
		# write out the data
		foreach ( $data as $row ) {
			fputcsv($fh, $row);
		}
		rewind($fh);
		$csv = stream_get_contents($fh);
		fclose($fh);
		return $csv;
	}
	protected function _arrToCsv($input, $delimiter = ',', $enclosure = '"')
    {
        // Open a memory "file" for read/write...
        $fp = fopen('php://temp', 'r+');
        // ... write the $input array to the "file" using fputcsv()...
        fputcsv($fp, $input, $delimiter, $enclosure);
        // ... rewind the "file" so we can read what we just wrote...
        rewind($fp);
        // ... read the entire line into a variable...
        $data = fread($fp, 1048576);
        // ... close the "file"...
        fclose($fp);
        // ... and return the $data to the caller, with the trailing newline from fgets() removed.
        return rtrim($data, "\n");
    }
}
