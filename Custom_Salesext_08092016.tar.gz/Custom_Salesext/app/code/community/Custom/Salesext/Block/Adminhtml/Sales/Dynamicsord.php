<?php
class Custom_Salesext_Block_Adminhtml_Sales_Dynamicsord extends Mage_Adminhtml_Block_Template
{
    public function __construct() {
		parent::__construct();
		$this->setTemplate('salesext/order/view/dynamics_ord.phtml');
    }
    public function getOrder() {
		return Mage::registry('current_order');
    }
    public function getFormUrl() {
		return Mage::helper("adminhtml")->getUrl('*/sales_order/editord', array('order_id' => $this->getOrder()->getId()));
    }
}
