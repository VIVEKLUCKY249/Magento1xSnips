<?php
require_once Mage::getModuleDir('controllers', 'Mage_Adminhtml') . DS . 'Sales' . DS . 'OrderController.php';
class Custom_Salesext_Adminhtml_Sales_OrderController extends Mage_Adminhtml_Sales_OrderController
{
    public function editordAction()
    {
		$postData = $this->getRequest()->getPost();
		Mage::log('Custom_Salesext_Adminhtml_Sales_OrderController::ordEditAction'.print_r($postData, true), 'custom_salesext.log');
		$id = $this->getRequest()->getParam('order_id');
		$order = Mage::getModel('sales/order')->load($id);
		$order->setDynamicsOrd($postData['dynamics_ord']);
		$order->save();
		$this->_getSession()->addSuccess(Mage::helper('sales')->__('Invoice Custom Comment has been updated successfully!!!'));
		// return to sales_order view
		Mage::app()->getResponse()->setRedirect(Mage::helper('adminhtml')->getUrl("adminhtml/sales_order/view", array('order_id' => $id)));
    }
}
