<?php
/**
 * Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@magentocommerce.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade Magento to newer
 * versions in the future. If you wish to customize Magento for your
 * needs please refer to http://www.magentocommerce.com for more information.
 *
 * @category    Mage
 * @package     Mage_Adminhtml
 * @copyright   Copyright (c) 2013 Magento Inc. (http://www.magentocommerce.com)
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */


/**
 * Product attribute add/edit form main tab
 *
 * @category   Mage
 * @package    Mage_Adminhtml
 * @author     Magento Core Team <core@magentocommerce.com>
 */
class Perc_Profile_Block_Adminhtml_Customer_Attribute_Edit_Tab_Main extends Mage_Eav_Block_Adminhtml_Attribute_Edit_Main_Abstract
{
    /**
     * Adding product form elements for editing attribute
     *
     * @return Mage_Adminhtml_Block_Catalog_Product_Attribute_Edit_Tab_Main
     */
    protected function _prepareForm()
    {
        parent::_prepareForm();
        $attributeObject = $this->getAttributeObject();
        /* @var $form Varien_Data_Form */
        $form = $this->getForm();
        /* @var $fieldset Varien_Data_Form_Element_Fieldset */
        $fieldset = $form->getElement('base_fieldset');

        $frontendInputElm = $form->getElement('frontend_input');
        $additionalTypes = array();


        $response = new Varien_Object();
        $response->setTypes(array());
        Mage::dispatchEvent('adminhtml_customer_attribute_types', array('response'=>$response));
        $_disabledTypes = array();
        $_hiddenFields = array();

        foreach ($response->getTypes() as $type) {
            $additionalTypes[] = $type;
            if (isset($type['hide_fields'])) {
                $_hiddenFields[$type['value']] = $type['hide_fields'];
            }
            if (isset($type['disabled_types'])) {
                $_disabledTypes[$type['value']] = $type['disabled_types'];
            }
        }



        Mage::register('attribute_type_hidden_fields', $_hiddenFields);
        Mage::register('attribute_type_disabled_types', $_disabledTypes);

        $frontendInputValues = array_merge($frontendInputElm->getValues(), $additionalTypes);

        foreach($frontendInputValues as $key => $_frontendInput)
        {
            if($_frontendInput["value"] == 'multiselect')
            {
                unset($frontendInputValues[$key]);
            }
        }


        $allStores = Mage::app()->getStores();
            $values = array();
	foreach ($allStores as $_eachStoreId):
	        $values[] = array('label' => Mage::app()->getStore($_eachStoreId)->getName(), 'value' => Mage::app()->getStore($_eachStoreId)->getCode());
		
	endforeach;
	 

        $frontendInputElm->setValues($frontendInputValues);

        $frontendInputElm->setLabel(Mage::helper("profile")->__("Input Type for Store Owner"));
        $yesnoSource = Mage::getModel('adminhtml/system_config_source_yesno')->toOptionArray();

        $scopes = array(
            Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_STORE =>Mage::helper('profile')->__('Store View'),
            Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_WEBSITE =>Mage::helper('profile')->__('Website'),
            Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_GLOBAL =>Mage::helper('profile')->__('Global'),
        );

        if ($attributeObject->getAttributeCode() == 'status' || $attributeObject->getAttributeCode() == 'tax_class_id') {
            unset($scopes[Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_STORE]);
        }

        $fieldset->addField('is_global', 'select', array(
            'name' => 'is_global',
            'label' => Mage::helper('profile')->__('Scope'),
            'title' => Mage::helper('profile')->__('Scope'),
            'note' => Mage::helper('profile')->__('Declare attribute value saving scope'),
            'values'=> $scopes
        ), 'attribute_code');


        $fieldset->addField('sort_order', 'text', array(
            'name' => 'sort_order',
            'label' => Mage::helper('profile')->__('Sort Order'),
            'title' => Mage::helper('profile')->__('Sort Order'),
            'note' => Mage::helper('profile')->__('This is the order according to which this field will display.')
        ));

				$data = Mage::registry('profile_data')->getData();
        $data['store_code'] = isset($data['store_code']) ? explode(',', $data['store_code']) : array();
        

        $fieldset->addField('store_code', 'multiselect', array(
					'name' => 'store_code',
					'class' => 'required-entry',
					'required' => true,
					'label' => Mage::helper('profile')->__('Select Store'),
					'title' => Mage::helper('profile')->__('Select Store'),
					'disabled' => false,
					'values' => $values,
					'value' => $data['store_code'],
					
        ));
       


        // frontend properties fieldset

        // define field dependencies
        $this->setChild('form_after', $this->getLayout()->createBlock('adminhtml/widget_form_element_dependence')
            ->addFieldMap("is_wysiwyg_enabled", 'wysiwyg_enabled')
            ->addFieldMap("is_html_allowed_on_front", 'html_allowed_on_front')
            ->addFieldMap("frontend_input", 'frontend_input_type')
            ->addFieldDependence('wysiwyg_enabled', 'frontend_input_type', 'textarea')
            ->addFieldDependence('html_allowed_on_front', 'wysiwyg_enabled', '0')
        );

				if ( Mage::getSingleton('adminhtml/session')->getProfileData() ) {
					$Profile1data = Mage::getSingleton('adminhtml/session')->getProfileData();
				} elseif ( Mage::registry('profile_data') ) {
					$Profile2data = Mage::registry('profile_data')->getData();
				}

				

        Mage::dispatchEvent('adminhtml_catalog_product_attribute_edit_prepare_form', array(
            'form' => $form,
            'attribute' => $attributeObject
        ));

        return $this;
    }


}
