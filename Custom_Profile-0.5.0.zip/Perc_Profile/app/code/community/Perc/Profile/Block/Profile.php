<?php
class Perc_Profile_Block_Profile extends Mage_Core_Block_Template
{
}