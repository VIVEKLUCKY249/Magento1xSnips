<?php

$installer = $this;

$installer->startSetup();

$installer->run("ALTER TABLE `".$this->getTable("profile/profile")."` ADD store_code VARCHAR(256) AFTER sort_order;");
$installer->run("ALTER TABLE `".$this->getTable("profile/profile")."` ADD store_id INT AFTER store_code;");

$installer->endSetup();