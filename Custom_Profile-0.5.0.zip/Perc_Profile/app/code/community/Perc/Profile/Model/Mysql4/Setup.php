<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Setup
 *
 * @author root
 */
class Perc_Profile_Model_Mysql4_Setup extends Mage_Core_Model_Resource_Setup
{
    //put your code here
}

?>
