<?php
/**
 * Custom_StoreLocator extension
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 * @category   Perception
 * @package    Custom_StoreLocator
 * @copyright  Copyright (c) 2008 Perception LLC
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

/**
 * @category   Perception
 * @package    Custom_StoreLocator
 * @author     Boris (Moshe) Gurevich <moshe@Perception.com>
 */
class Custom_StoreLocator_Block_Adminhtml_Location_Edit_Tab_Import extends Mage_Adminhtml_Block_Widget_Form
{
    protected function _prepareForm()
    {
    	$form = new Varien_Data_Form();
        $this->setForm($form);

        $fieldset = $form->addFieldset('location_form', array(
            'legend'=>Mage::helper('cstorelocator')->__('Import Store Location Information')
        ));

        $fieldset->addField('import', 'file', array(
          'label'     => Mage::helper('cstorelocator')->__('Choose File'),
          'required'  => true,
          'name'      => 'import',
	  'after_element_html' => '<br /><label><small>Supported file formats (.csv)</small></label><br /><label><small>copy store image to media/storelocator/store/ and <br/> copy map marker image to media/storelocator/marker/</small></label><br /><br /><button type="button" onclick="downloadfile();">Export sample file</button>',
	  	));
        

        return parent::_prepareForm();
    }
}
$mediaurl =  Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_MEDIA); 
?>

<script language="javascript" >
function downloadfile()
{
    window.location.href = '<?php echo $mediaurl.'storelocator/sample.csv';  ?>';
}
</script>    