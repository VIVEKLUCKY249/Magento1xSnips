<?php
/**
 * Custom_StoreLocator extension
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 * @category   Perception
 * @package    Custom_StoreLocator
 * @copyright  Copyright (c) 2008 Perception LLC
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

/**
 * @category   Perception
 * @package    Custom_StoreLocator
 * @author     Boris (Moshe) Gurevich <moshe@Perception.com>
 */
class Custom_StoreLocator_Block_Adminhtml_Location_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
    protected function _prepareForm()
    {
    	$countries = Mage::getModel('directory/country_api')->items();
    	$contry=array();
    	$contry['']='-- Please Select --';
    	$state=array();
    	$state['']='-- Please Select --';
    	foreach ($countries as $cont) {
    		$contry[$cont['iso2_code']]=$cont['name'];
    	}
    	
        $form = new Varien_Data_Form();
        
       
        $fieldset = $form->addFieldset('location_form', array(
            'legend'=>Mage::helper('cstorelocator')->__('Store Location Info')
        ));

        $fieldset->addField('enable', 'select', array(
            'name'      => 'enable',
            'label'     => Mage::helper('cstorelocator')->__('Enable'),
            'class'     => 'required-select',
            'required'  => true,
            'values'     => array('0'=>'No','1'=>'Yes'),
        ));
        
        $fieldset->addField('title', 'text', array(
            'name'      => 'title',
            'label'     => Mage::helper('cstorelocator')->__('Title'),
            'class'     => 'required-entry',
            'required'  => true,
        ));
        
        $fieldset->addField('storeimg', 'image', array(
          'label'     => Mage::helper('cstorelocator')->__('Choose Store Image'),
          'name'      => 'storeimg',
          'required'  => false
	));
        
        $fieldset->addField('markerimg', 'image', array(
          'label'     => Mage::helper('cstorelocator')->__('Choose Store marker mage'),
          'name'      => 'markerimg',
          'required'  => false
	));
        
        
        $fieldset->addField('address_display', 'textarea', array(
            'name'      => 'address_display',
            'label'     => Mage::helper('cstorelocator')->__('Address to be displayed'),
            'class'     => 'required-entry',
            'style'     => 'height:50px',
            'required'  => true,
            'note'      => Mage::helper('cstorelocator')->__('This address will be shown to visitor and should have multiple lines formatting'),
        ));
        $fieldset->addField('country', 'select', array(
            'name'      =>  'country',
            'label'     =>  Mage::helper('cstorelocator')->__('Country'),
            'class'     =>  'required-select',
            'required'  =>  true,
            'values'	=>  $contry,
            'onchange'  =>  'fillstate(this.value);',
        ));
        
                
        if (Mage::registry('location_data')) {
                $data=Mage::registry('location_data')->getData();				
		$st = Mage::getModel('directory/region_api')->items($data['country']);
		if(!empty($st))
		{
                    foreach ($st as $val)
                    {
                        $state[$val['code']]=$val['name'];
                    }
		}
		else
		$state_val=$data['state'];
         
         }
      
		
	$fieldset->addField('state', 'select', array(
	    	'name'      => 	'state',
	        'label'     => 	Mage::helper('cstorelocator')->__('State'),
            'class'     =>  'required-select',
            'required'  =>  true,
	        'values'    =>	$state,
			'after_element_html' => '<input id="state2" class="input-text" type="text" value="" name="state2" style="display:none;" />',
	));
	
      
         
	$fieldset->addField('city', 'text', array(
            'name'      => 'city',
            'label'     => Mage::helper('cstorelocator')->__('City'),
            'class'     => 'required-entry',
            'required'  => true,
        ));
        
        $fieldset->addField('zipcode', 'text', array(
            'name'      => 'zipcode',
            'label'     => Mage::helper('cstorelocator')->__('Zipcode'),
            'class'     => 'required-entry',
            'required'  => true,
        ));
        
        $fieldset->addField('phone', 'text', array(
            'name'      => 'phone',
            'label'     => Mage::helper('cstorelocator')->__('Phone'),
        ));

        $fieldset->addField('website_url', 'text', array(
            'name'      => 'website_url',
            'label'     => Mage::helper('cstorelocator')->__('Website URL / Email'),
            'note'      => Mage::helper('cstorelocator')->__('For websites URL please start with http://'),
        ));


        $fieldset = $form->addFieldset('geo_form', array(
            'legend'=>Mage::helper('cstorelocator')->__('Geo Location')
        ));

        $fieldset->addField('address', 'textarea', array(
            'name'      => 'address',
            'style'     => 'height:50px',
            'label'     => Mage::helper('cstorelocator')->__('Address for geo location'),
            'note'      => Mage::helper('cstorelocator')->__('This address will be used to calculate latitude and longitude, free format is allowed.<br/>If left empty, will be copied from address to be displayed.'),
        ));

        $fieldset->addField('longitude', 'text', array(
            'name'      => 'longitude',
            'label'     => Mage::helper('cstorelocator')->__('Longitude'),
            'note'      => Mage::helper('cstorelocator')->__('If empty, will attempt to retrieve using the geo location address.'),
        ));

        $fieldset->addField('latitude', 'text', array(
            'name'      => 'latitude',
            'label'     => Mage::helper('cstorelocator')->__('Latitude'),
        ));
        
        Mage::dispatchEvent('cstorelocator_adminhtml_edit_prepare_form', array('block'=>$this, 'form'=>$form));

        if (Mage::registry('location_data')) 
        {
            $form->setValues(Mage::registry('location_data')->getData());
        }
$this->setForm($form);
        return parent::_prepareForm();
    }
}

$mediaurl =  Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_MEDIA); 
$default_marker = Mage::getStoreConfig('cstorelocator/general/default_marker');

if($default_marker == '')
{
    $default_marker_path = $mediaurl.'storelocator/map.png';   
}
else
{    
    $default_marker_path = $mediaurl.'theme/'.$default_marker;
}

$default_store = Mage::getStoreConfig('cstorelocator/general/default_store_img');
if($default_store_path == '')
{
    $default_store_path = $mediaurl.'storelocator/store-icon_1.png';   
} 
else
{
   $default_store_path = $mediaurl.'theme/'.$default_store;
}

?>
<script type="text/javascript"src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA3lHatj4OEZU_JA4oRtUfFL96h8ZssEVU&sensor=false"></script>

<script>
    
    
function loadScript(){
          
            var div = document.createElement('div');
            div.id='map';
            document.getElementsByClassName('hor-scroll')[0].appendChild(div);
            var img = document.createElement('img');
          //  document.getElementsByClassName('form-list')[0].style.float='left';
            document.getElementById('map').style.height='420px';
            document.getElementById('map').style.width='47%';
            document.getElementById('map').style.float='left';
           /* document.getElementById('map').style.marginLeft='30px'; */
            document.getElementById('map').style.marginTop='5px';
           $$('.form-list').invoke('setStyle', {float:'left'});
            getLatLng();
}     

 function initialize() {
      
        var lat='',lng='';
        
        lat = document.getElementById('latitude').value;
        lng = document.getElementById('longitude').value;
        var mapOptions = {
          center: new google.maps.LatLng(lat, lng),
          zoom: 5,
          mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        var map = new google.maps.Map(document.getElementById("map"), mapOptions);
 }
 
 function capitalize(str) 
 {
   var pieces = str.split(' ');
   for ( var i = 0; i < pieces.length; i++ )
    {
       var j = pieces[i].charAt(0).toUpperCase();
       pieces[i] = j + pieces[i].substr(1);
    }
    return pieces.join(' ');
 } 
 
 
function getLatLng(){
    
        var imgMarker = new google.maps.MarkerImage('<?php echo $default_marker_path; ?>');
        var geocoder = new google.maps.Geocoder();
        var address = document.getElementById('address').value;
        var displayaddress = document.getElementById('address_display').value;
        var city = document.getElementById('city').value;
        var country = document.getElementById('country').options[document.getElementById('country').selectedIndex].text;
        var imgStore = storeImage = '';
        if(document.getElementById('storeimg_image'))
        {
            storeImage = document.getElementById('storeimg_image').src;
            imgStore = '<div><img src='+storeImage+' alt='+document.getElementById('title').value+' style=\'float:left;width:150px;\'/></div>';
        }
        else
        {
             imgStore = '<div><img src="<?php echo $default_store_path; ?>" alt='+document.getElementById('title').value+' style=\'float:left;width:150px;\'/></div>';
            
        }
        if(document.getElementById('markerimg_image'))
        {
           storeMarker = document.getElementById('markerimg_image').src;
        }
        
        if(address != '' && city != '')
        {
            var addressComplete = address; // + ', ' + city;
           
            if(country != '') // addressComplete = addressComplete; // + ' ' + country;
           
            geocoder.geocode( { 'address': addressComplete}, function(results, status)
            {
               
                if (status == google.maps.GeocoderStatus.OK) 
                {
                   
                    document.getElementById('latitude').value = results[0].geometry.location.lat();
                    document.getElementById('longitude').value = results[0].geometry.location.lng();
                    document.getElementById('address').value = capitalize(document.getElementById('address').value);
                    document.getElementById('city').value = capitalize(document.getElementById('city').value);
                    var latLng = new google.maps.LatLng(document.getElementById('latitude').value , document.getElementById('longitude').value);
                    var mapOption = {zoom: 5, center: latLng, mapTypeId: google.maps.MapTypeId.ROADMAP, disableDefaultUI : true };
                    map = new google.maps.Map(document.getElementById('map'), mapOption);
                    
                    if(document.getElementById('markerimg_image'))
                    {
                    
                        storeMarker = document.getElementById('markerimg_image').src;
                        var marker = new google.maps.Marker({position: latLng, icon: storeMarker,map: map });
                    }
                    else
                    {
                        var marker = new google.maps.Marker({position: latLng, icon: imgMarker,map: map });
                    }
                     
                    var infoWindow = new google.maps.InfoWindow();
                     if(displayaddress != '') { addressComplete = displayaddress }
                    google.maps.event.addListener(marker, 'click', (function(marker) {
                        return function() {
                                var content = imgStore+'<div style=\' width:170px; float:left;margin:10px 0 0 10px;\' ><h3>' + document.getElementById('title').value + '</h3>'+ displayaddress + '<br>'
+' <br>' + document.getElementById('phone').value + '<br>' + '</div>';
                                
                                infoWindow.setContent(content);
                                infoWindow.open(map,marker);
                        }
            })(marker));
        }
    });
  }
} 


var http = false;

if(navigator.appName == "Microsoft Internet Explorer") {
    http = new ActiveXObject("Microsoft.XMLHTTP");
} else {
    http = new XMLHttpRequest();
}

window.onload=function(){
    var lat = document.getElementById('latitude').value;
    var lng = document.getElementById('longitude').value;
    if(lat != '' && lng != '')
    {   
	loadScript();
    }    
<?php   if (Mage::registry('location_data')) {
	$data=Mage::registry('location_data')->getData();
	$st = Mage::getModel('directory/region_api')->items($data['country']);	
if(empty($st))	
{
?>
document.getElementById('state2').value ='<?php echo $data["state"]; ?>';
document.getElementById('state2').style.display ='block';
document.getElementById('state2').className="required-entry input-text";
document.getElementById('state').style.display ='none';
document.getElementById('state').className=" select required-select";
<?php }
}
else {?>
document.getElementById('state').style.display ='block';
document.getElementById('state2').style.display ='none';
document.getElementById('state2').className=" input-text";
document.getElementById('state').className="required-entry select required-select";

<?php } ?>
	
//document.getElementById('state').parentNode.parentNode.style.display ='table-row';
<?php if(strlen($data["state"]) <= 2): ?>
	document.getElementById('state2').style.display ='none';
        document.getElementById('state2').className=" input-text";
        document.getElementById('state').className="required-entry select required-select";
<?php endif; ?>



}

function fillstate(id,changetype)
 {
   if(id!=0)
   {
	var url="<?php echo Mage::getBaseUrl()?>cstorelocatoradmin/location/admin_ajaxstate/?id="+id;
	http.abort();
	http.open("GET", url, true);
	http.onreadystatechange=function() 
        {
          if(http.responseText!='<option value="">-- Please Select --</option>')
	  {
	     document.getElementById('state').innerHTML = http.responseText;
	     document.getElementById('state').style.display ='block';
             document.getElementById('state2').style.display ='none';
	     document.getElementById('state').className="required-entry select required-select";
	     document.getElementById('state2').className="input-text";
             if(document.getElementById('advice-required-entry-state2'))
             {
                document.getElementById('advice-required-entry-state2').style.display = 'none';
             }
	  }
	  else
	  {
             document.getElementById('state').style.display ='none';
	     document.getElementById('state2').style.display ='block';
	     document.getElementById('state2').className="input-text required-entry";
             document.getElementById('state').className="select required-select";
             if(document.getElementById('advice-required-entry-state'))
             {
               document.getElementById('advice-required-entry-state').style.display = 'none';
	             
             }
             document.getElementById('state2').value ='';
	     document.getElementById('state').className="";
	  }
        }
          http.send(null);
    }
}
</script>
<?php ?>