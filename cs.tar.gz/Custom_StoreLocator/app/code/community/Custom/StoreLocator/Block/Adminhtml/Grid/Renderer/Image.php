<?php

class Custom_StoreLocator_Block_Adminhtml_Grid_Renderer_Image extends Mage_Adminhtml_Block_Widget_Grid_Column_Renderer_Abstract
{
   public function render(Varien_Object $row)
    {
       $mediaurl =  Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_MEDIA); 
        if($row->getStoreimg() == ""){
            $default_store = Mage::getStoreConfig('cstorelocator/general/default_store_img');
$default_store_path = $mediaurl.'theme/'.$default_store;
            return "<img id='".$this->getColumn()->getId()."' src='".$default_store_path."' width='50' height='50'/>";
        }
        else
        {
            return "<img id='".$this->getColumn()->getId()."' src='".$mediaurl.$row->getData($this->getColumn()->getIndex())."' width='50' height='50'/>";
        
           
        }
    }
} 