<?php
/**
 * Custom_StoreLocator extension
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 * @category   Perception
 * @package    Custom_StoreLocator
 * @copyright  Copyright (c) 2008 Perception LLC
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OS	L 3.0)
 */


class Custom_StoreLocator_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
      if(!Mage::getStoreConfig('cstorelocator/general/enable_storelocator'))
        {
          $this->getResponse()->setHeader('HTTP/1.1','404 Not Found'); 
          $this->getResponse()->setHeader('Status','404 File not found'); 
          $this->_forward('defaultNoRoute');  
        }
        else
        {
          $this->loadLayout();
          $this->renderLayout();
        }   
    }

    public function searchAction()
    {
        $dom = new DOMDocument("1.0");
        $node = $dom->createElement("markers");
        $parnode = $dom->appendChild($node);

        try {
            $num = (int)Mage::getStoreConfig('cstorelocator/general/num_results');
            $units = Mage::getStoreConfig('cstorelocator/general/distance_units');
            $collection = Mage::getModel('cstorelocator/location')->getCollection()
                ->addAreaFilter(
                    $this->getRequest()->getParam('lat'),
                    $this->getRequest()->getParam('lng')
                )
                ->addFieldToFilter('enable','1')
                ->addProductTypeFilter($this->getRequest()->getParam('type'));

            $privateFields = Mage::getConfig()->getNode('global/cstorelocator/private_fields');
            $i = 0;
            foreach ($collection as $loc){
                $node = $dom->createElement("marker");
                $newnode = $parnode->appendChild($node);
                $newnode->setAttribute("units", $units);
                $newnode->setAttribute("marker_label", ++$i);
                foreach ($loc->getData() as $k=>$v) {
                    if (!$privateFields->$k) {
                        $newnode->setAttribute($k, $v);
                    }
                }
            }
        } catch (Exception $e) {
            $node = $dom->createElement('error');
            $newnode = $parnode->appendChild($node);
            $newnode->setAttribute('message', $e->getMessage());
        }

        $this->getResponse()->setHeader('Content-Type', 'text/xml', true)->setBody($dom->saveXml());
    }
     public function admin_ajaxstateAction()
     {
    	$id=$this->getRequest()->getParam('id');
		$state = Mage::getModel('directory/region_api')->items($id);
    	$collection = Mage::getModel('cstorelocator/location')->getCollection()->addFieldToFilter('country',$id)->addFieldToFilter('enable','1');
		$state_arr=array();
    	$st='<option value="">-- Please Select --</option>';
      
    	foreach ($state as $value)
    	{
    	   $st.='<option value="'.$value['code'].'">'.$value['name'].'</option>';
    	}
    	echo $st;
        exit;
    }
    public function ajaxstateAction()
    {
    	$id=$this->getRequest()->getParam('id');
		$state = Mage::getModel('directory/region_api')->items($id);
		$collection = Mage::getModel('cstorelocator/location')->getCollection()->addFieldToFilter('country',$id)->addFieldToFilter('enable','1');
		$state_arr=array();
		$city_arr=array();
		foreach($collection as $col)
		{	
			if($col['country'] == $id)
			array_push($state_arr,$col['state']);
			
			if($col['state']==$id)
			array_push($city_arr,$col['city']);
		}
              
               $stateMapping = $this->statemange($state);
	       $st='<option value="0">--Select State--</option>';
               foreach ($collection  as $state)
			{
                            if($stateMapping[$state['state']])
                            {    
                              $st.='<option value="'.$state['state'].'">'.$stateMapping[$state['state']].'</option>';
                            }
                            else
                            {
                              $st.='<option value="'.$state['state'].'">'.$state['state'].'</option>';   
                            }    
			}
                
		
               
	   	echo $st;
                exit;
    }
    
    public function statemange($statearr)
    {
        $state_mapping = array();
       if(is_array($statearr))
       {
           foreach ($statearr as $stateval)
           {
              $statecode = $stateval['code'];
              $statevalue = $stateval['name'];
              $state_mapping[$statecode] = $statevalue;
           }
       }
       return $state_mapping;
    }
	 public function ajaxcityAction()
    {
    	$id=$this->getRequest()->getParam('id');
    	$collection = Mage::getModel('cstorelocator/location')->getCollection()->addFieldToFilter('enable','1');
		$city_arr=array();
		$city_state_arr = array();
		foreach($collection as $col)
		{
			if($col['country']==$id)
			array_push($city_arr,$col['city']);
			
			if($col['state']==$id)
			array_push($city_state_arr,$col['city']);
		}
		
    	$st='<option value="0">--Select City--</option>';
    	
		if(count($city_state_arr) != 0){
			foreach ($city_state_arr as $city)
				{
                                        $city2 = str_replace(' ', '_', $city);
					$st.='<option value="'.$city2.'">'.$city.'</option>';
				}
			
    	}else{
				foreach ($city_arr as $city)
				{
                                    $city2 = str_replace(' ', '_', $city);
					$st.='<option value="'.$city2.'">'.$city.'</option>';
				}
			 }
			 
    	echo $st;
    }
	

	public function collectionAction()
    {
		$country=$this->getRequest()->getParam('country');
		$state=$this->getRequest()->getParam('state');
		$city=$this->getRequest()->getParam('city');
    	$collection = Mage::getModel('cstorelocator/location')->getCollection()->addFieldToFilter('enable','1');
    	$data=array();
		$i=0;
		foreach ($collection as $coll)
    	{
    	   if($country!=0)
	       {
		       if($country==$coll['country'])
		       {
		    		if($state!=0)
		    		{
			    		if($state==$coll['state'])
			    		{
							
							if($city!=0)
							{
								$city=strtolower($city);
								if(strstr(strtolower($coll['city']),$city))
								{
									$data[$i]['latitude']=$coll['latitude'];
									$data[$i]['longitude']=$coll['longitude'];
									$data[$i]['title']=$coll['title'];
									$data[$i]['address']=$coll['address'];
									$data[$i]['city']=$coll['city'];
									$data[$i]['state']=$coll['state'];
									$data[$i]['country']=$coll['country'];
									$i++;	
								}
							}
							else
							{
							
									$data[$i]['latitude']=$coll['latitude'];
									$data[$i]['longitude']=$coll['longitude'];
									$data[$i]['title']=$coll['title'];
									$data[$i]['address']=$coll['address'];
									$data[$i]['city']=$coll['city'];
									$data[$i]['state']=$coll['state'];
									$data[$i]['country']=$coll['country'];
									$i++;	
							}
			    		}
		    		}
		    		else
		    		{
							if($city!=0)
							{
								$city=strtolower($city);	
								if(strstr(strtolower($coll['city']),$city))
								{
									$data[$i]['latitude']=$coll['latitude'];
									$data[$i]['longitude']=$coll['longitude'];
									$data[$i]['title']=$coll['title'];
									$data[$i]['address']=$coll['address'];
									$data[$i]['city']=$coll['city'];
									$data[$i]['state']=$coll['state'];
									$data[$i]['country']=$coll['country'];
									$i++;	
								}
							}
							else
							{
							
									$data[$i]['latitude']=$coll['latitude'];
									$data[$i]['longitude']=$coll['longitude'];
									$data[$i]['title']=$coll['title'];
									$data[$i]['address']=$coll['address'];
									$data[$i]['city']=$coll['city'];
									$data[$i]['state']=$coll['state'];
									$data[$i]['country']=$coll['country'];
									$i++;	
							}
		    			}
			  }
		       
	       }
	       else
	       {
				 			if($city!=0)
							{
								$city=strtolower($city);	
								if(strstr(strtolower($coll['city']),$city))
								{
									$data[$i]['latitude']=$coll['latitude'];
									$data[$i]['longitude']=$coll['longitude'];
									$data[$i]['title']=$coll['title'];
									$data[$i]['address']=$coll['address'];
									$data[$i]['city']=$coll['city'];
									$data[$i]['state']=$coll['state'];
									$data[$i]['contry']=$coll['contry'];
									$i++;	
								}
							}
							else
							{
									$data[$i]['latitude']=$coll['latitude'];
									$data[$i]['longitude']=$coll['longitude'];
									$data[$i]['title']=$coll['title'];
									$data[$i]['address']=$coll['address'];
									$data[$i]['city']=$coll['city'];
									$data[$i]['state']=$coll['state'];
									$data[$i]['contry']=$coll['contry'];
									$i++;	
							}
				
		   }

    	}
		
		echo "<pre>";
		print_r($data);
	
    }
    
}
