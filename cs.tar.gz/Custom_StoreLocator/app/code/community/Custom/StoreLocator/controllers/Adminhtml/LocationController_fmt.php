<?php
class Custom_StoreLocator_Adminhtml_LocationController extends Mage_Adminhtml_Controller_Action
{
    public function indexAction()
    {
        $this->loadLayout();
		$this->_setActiveMenu('custom/custom');
        $this->_addBreadcrumb(Mage::helper('adminhtml')->__('Store Locations'), Mage::helper('adminhtml')->__('Store Locations'));
        $this->_addContent($this->getLayout()->createBlock('cstorelocator/adminhtml_location'));
        $this->renderLayout();
    }
    public function editAction()
    {
        $this->loadLayout();
        $this->_setActiveMenu('custom/custom');
        $this->_addBreadcrumb(Mage::helper('adminhtml')->__('Store Locations'), Mage::helper('adminhtml')->__('Store Locations'));
        $this->_addContent($this->getLayout()->createBlock('cstorelocator/adminhtml_location_edit'))
            ->_addLeft($this->getLayout()->createBlock('cstorelocator/adminhtml_location_edit_tabs'));
        $this->renderLayout();
    }
    public function newAction()
    {
        $this->editAction();
        ## $this->_forward('edit');
    }
    public function saveAction()
    {
        if ($data = $this->getRequest()->getPost() ) {
            $id = $this->getRequest()->getParam('id');
            ## echo "<pre/>";print_r($id);die;
        try {
            if(isset($_FILES['import'])) {
                if($this->importStoreLocations($_FILES['import'])) {
                    Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('adminhtml')->__('Import Store location successfully.'));
                    $this->_redirect('*/*/');
                    return;
                }
                else {
                    Mage::getSingleton('core/session')->addError(Mage::helper('adminhtml')->__('In valid file format. Please import CSV file.'));
                    $this->_redirect('*/*/import');
                    return;
                }
            }
				if($this->getRequest()->getParam('state')){ 
                  $data['state'] = $this->getRequest()->getParam('state'); 
				}
				if($this->getRequest()->getParam('state2')){
				  $data['state'] = $this->getRequest()->getParam('state2');
				}
				if(isset($_FILES['storeimg']['name']) && $_FILES['storeimg']['name'] != '')
                {
                    try
                    {
                        /* Starting upload */
                        $storeimg_uploader = new Varien_File_Uploader('storeimg');
                        $storeimg_uploader->setAllowedExtensions(array('jpg','jpeg','gif','png'));
                        $storeimg_uploader->setAllowRenameFiles(false);
                        $storeimg_uploader->setFilesDispersion(false);
                        $path = Mage::getBaseDir('media') . DS . 'storelocator' . DS . 'store';
                        $storeimg_uploader->save($path, $_FILES['storeimg']['name'] );
                    }
                                  catch (Exception $e) {}
                                  $storeimg = str_replace(" ","_",$_FILES['storeimg']['name']); 
                                  $data['storeimg'] = 'storelocator/store/'.$storeimg; 	
                                }
                               else
                                {
                                    if(isset($data['storeimg']['delete']) && $data['storeimg']['delete'] == 1)
                                    {
                                    $data['storeimg'] = '';
                                    }
                                    else 
                                    {
                                     unset($data['storeimg']);
                                    }
                                }
                                if(isset($_FILES['markerimg']['name']) && $_FILES['markerimg']['name'] != '')
                                {
                                  try
                                  {	
			                $markerimg_uploader = new Varien_File_Uploader('markerimg');
                            $markerimg_uploader->setAllowedExtensions(array('jpg','jpeg','gif','png'));
                            $markerimg_uploader->setAllowRenameFiles(false);
                            $markerimg_uploader->setFilesDispersion(false);
					$path = Mage::getBaseDir('media') . DS . 'storelocator' . DS . 'marker';
					$markerimg_uploader->save($path, $_FILES['markerimg']['name'] );
			          } 
                                  catch (Exception $e) {}
                                  $markerimg = str_replace(" ","_",$_FILES['markerimg']['name']); 
                                  $data['markerimg'] = 'storelocator/marker/'.$markerimg; 	
                                }
                               else
                                {
                                    if(isset($data['markerimg']['delete']) && $data['markerimg']['delete'] == 1)
                                    {
                                    $data['markerimg'] = '';
                                    }
                                    else 
                                    {
                                     unset($data['markerimg']);
                                    }
                                }
                $model = Mage::getModel('cstorelocator/location');
                $model->setData($data);
                $model->setId($id);
                try 
                {
                    $model->save();
                    Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('adminhtml')->__('Store location was successfully saved'));
                    $this->_redirect('*/*/');
                    return;
                }
                catch (Exception $e)
                {
                    Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
                    Mage::getSingleton('adminhtml/session')->setFormData($data);
                    $this->_redirect('*/*/edit', array('id' => $this->getRequest()->getParam('id')));
                    return;
                }
            } catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
                $this->_redirect('*/*/edit', array('id' => $this->getRequest()->getParam('id')));
                return;
            }
        }
        $this->_redirect('*/*/');
    }
    public function deleteAction()
    {
        if( $this->getRequest()->getParam('id') > 0 ) {
            try {
                $model = Mage::getModel('cstorelocator/location');
                /* @var $model Mage_Rating_Model_Rating */
                $model->setId($this->getRequest()->getParam('id'))
                    ->delete();
                Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('adminhtml')->__('Store location was successfully deleted'));
                $this->_redirect('*/*/');
            } catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
                $this->_redirect('*/*/edit', array('id' => $this->getRequest()->getParam('id')));
            }
        }
        $this->_redirect('*/*/');
    }
    public function massDeleteAction() {
        $cstorelocatorIds = $this->getRequest()->getParam('cstorelocator');
        if(!is_array($cstorelocatorIds)) {
			Mage::getSingleton('adminhtml/session')->addError(Mage::helper('adminhtml')->__('Please select item(s)'));
        } else {
            try {
                foreach ($cstorelocatorIds as $cstorelocatorId) {
                    $bannerpro = Mage::getModel('cstorelocator/location')->load($cstorelocatorId);
                    $bannerpro->delete();
                }
                Mage::getSingleton('adminhtml/session')->addSuccess(
                    Mage::helper('adminhtml')->__(
                        'Total of %d record(s) were successfully deleted', count($cstorelocatorIds)
                    )
                );
            } catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
            }
        }
        $this->_redirect('*/*/index');
    }
    protected function _validateSecretKey()
    {
        if ($this->getRequest()->getActionName()=='updateEmptyGeoLocations') {
            return true;
        }
        return parent::_validateSecretKey();
    }
    public function updateEmptyGeoLocationsAction()
    {
        set_time_limit(0);
        ob_implicit_flush();
        $collection = Mage::getModel('cstorelocator/location')->getCollection();
        $collection->getSelect()->where('latitude=0');
        foreach ($collection as $loc) {
            echo $loc->getTitle()."<br/>";
            $loc->save();
        }
        exit;
    }
    public function importAction()
    {
        $this->loadLayout();
        $this->_setActiveMenu('custom/custom');
        $this->_addBreadcrumb(Mage::helper('adminhtml')->__('Store Locations'), Mage::helper('adminhtml')->__('Store Locations'));
        $this->_addContent($this->getLayout()->createBlock('cstorelocator/adminhtml_location_import'))
				->_addLeft($this->getLayout()->createBlock('cstorelocator/adminhtml_location_edit_import'));
        $this->renderLayout();
    }
	public function importStoreLocations($importFile) {
           $mediaurl =  Mage::getBaseDir('media') . DS;
		$config  = Mage::getConfig()->getResourceConnectionConfig("default_setup");
		$_host = $config->host;
		$_uname = $config->username;
		$_pass = $config->password;
		$_dbname = $config->dbname;
		$db = mysql_connect($_host, $_uname, $_pass) or die("Could not connect.");
		if(!mysql_select_db($_dbname,$db)){
			die("No database selected.");
		}
		mkdir($mediaurl."storelocator/upload");
		$uploaddir = $mediaurl.'storelocator/upload/';
		$uploadfile = $uploaddir . basename($importFile['name']);
		$allow_types = array("csv","xls");
		$filename = $importFile['name'];
		$explode = explode(".",$filename);
		$count = count($explode);
		$file_ext = $explode[$count-1];
                if(in_array($file_ext,$allow_types)) {
			// upload the file
			if (move_uploaded_file($importFile['tmp_name'], $uploadfile)) {
				//echo "File is valid, and was successfully uploaded.\n";
				$select = "SELECT * FROM cstorelocator_location";
				$result = mysql_query($select,$db);
				$total_row = mysql_num_rows($result);
				if($total_row > 0) {
					while($fetch_data = mysql_fetch_row($result)) {
						$latitude[] = $fetch_data[6];
						$longitude[] = $fetch_data[7];
					}
				}
                                if($file_ext == 'csv')
                                {    
                                    if (($handle = fopen($uploadfile, "r")) != FALSE) {
					$row = 0;
                                        $datasize = 0;
					while (($data = fgetcsv($handle, 10000, ";")) != FALSE) {
                                               $datasize = sizeof($data);
						if($row != 0) {
                                                    $storeimg = '';
                                                    $markerimg = '';
                                                    if($data[0] != '')
                                                    {
                                                     $storeimg = 'storelocator/store/'.$data[0];
                                                    }
                                                    if($data[1] != '')
                                                    {    
                                                     $markerimg = 'storelocator/marker/'.$data[1];
                                                    } 
                                                     if(in_array($data[8], $latitude) && in_array($data[9], $longitude)) {
								$update = "UPDATE  cstorelocator_location SET 
                                                                                        storeimg =  '$storeimg',
                                                                                        markerimg =  '$markerimg', 
                                                                                        title =  '$data[2]',
											address =  '$data[3]',
											country = '$data[4]',
											state =  '$data[5]',
											city =  '$data[6]',
                                                                                        zipcode =  '$data[7]',
											latitude = '$data[8]',
											longitude = '$data[9]',
											address_display = '$data[10]',
											website_url =  '$data[11]',
											phone =  '$data[12]',
											product_types =  '$data[13]' WHERE latitude = '$data[8]' AND longitude = '$data[9]';";
								mysql_query($update,$db) or die(mysql_error());
							}
							else 
                                                         {
								$insert = "INSERT into cstorelocator_location(storeimg,markerimg,title,address,country,state,city,zipcode,latitude,longitude,address_display,website_url,phone,product_types) 
                                                                                                       values('$storeimg','$markerimg','$data[2]','$data[3]','$data[4]','$data[5]','$data[6]','$data[7]','$data[8]','$data[9]','$data[10]','$data[11]','$data[12]','$data[13]')";
								mysql_query($insert,$db) or die(mysql_error());
                                                        }
                                                }
						$row++;
					}
				}
                                fclose($handle);
                                return true;
                               }
                                if($file_ext == 'xls')
                                {
                                    $xlsData = $this->loadXML($uploadfile);
                                    $numRows = $xlsData->sheets[0]['numRows'];
                                    $numColumns = $xlsData->sheets[0]['numCols'];
                                    $data = '';
                                    for($row=1;$row<$numRows;$row++)
                                    {
                                        $data = '';
                                      for($col=0;$col<$numColumns;$col++)
                                      {
                                        $data[$col] = $xlsData->sheets[0]['cells'][$row][$col];
                                      }
                                      $datasize = sizeof($data);
                                      $storeimg = '';
                                      $markerimg = '';
                                      if($data[0] != '')
                                      {
                                         $storeimg = 'storelocator/store/'.$data[0];
                                      }
                                      if($data[1] != '')
                                      {    
                                         $markerimg = 'storelocator/marker/'.$data[1];
                                      } 
                                      if(in_array($data[8], $latitude) && in_array($data[9], $longitude))
                                      {
            				$update = "UPDATE cstorelocator_location SET 
                                                     storeimg =  '$storeimg',
                                                     markerimg =  '$markerimg',    
                                                     title =  '$data[2]',
                                                     address =  '$data[3]',
                                                     country = '$data[4]',
                                                     state =  '$data[5]',
                                                     city =  '$data[6]',
                                                     zipcode =  '$data[7]',    
                                                     latitude = '$data[8]',
                                                     longitude = '$data[9]',
                                                     address_display = '$data[10]',
                                                     website_url =  '$data[11]',
                                                     phone =  '$data[12]',
                                                     product_types =  '$data[13]' 
                                                   WHERE latitude = '$data[8]' AND longitude = '$data[9]';";
						   mysql_query($update,$db) or die(mysql_error());
					}
					else
                                        {
					   $insert = "INSERT into cstorelocator_location(storeimg,markerimg,title,address,country,state,city,zipcode,latitude,longitude,address_display,website_url,phone,product_types) values('$storeimg','$markerimg','$data[2]','$data[3]','$data[4]','$data[5]','$data[6]','$data[7]','$data[8]','$data[9]','$data[10]','$data[11]','$data[12]','$data[13]')";
					   mysql_query($insert,$db) or die(mysql_error());
                                        }
                                  }
                                return true;
                                }
                            Mage::getSingleton('core/session')->addError(Mage::helper('adminhtml')->__('Please try again file is not uploaded successfully.')); 
                            return false;  
			}
                        else
                        {
                            Mage::getSingleton('core/session')->addError(Mage::helper('adminhtml')->__('Please give permission to upload directory.')); 
                            return false;
                        }
		} 
                else 
                {
		  return false;
		}
	}
    protected function _isAllowed()
    {
        return Mage::getSingleton('admin/session')->isAllowed('cstorelocator/cstorelocator');
    }
    public function exportCsvAction()
    {
        $fileName   = 'storelocator.csv';
        //$content    = $this->getLayout()->createBlock('cstorelocator/adminhtml_location_grid')->getCsv();
        $content = 'STORE IMAGE;MARKER IMAGE;TITLE;ADDRESS;COUNTRY_CODE;STATE;CITY;ZIPCODE;LATITUDE;LONGITUDE;DISPLAY ADDRESS;WEBSITE URL;PHONE NO.;PRODUCT TYPE'."\n";
        $collections = Mage::getModel('cstorelocator/location')->getCollection();
        $storeimg = '';
        $markerimg = '';
        foreach($collections as $item)
        {
            $storeimg = explode("/",$item->getStoreimg());
            $markerimg = explode("/",$item->getMarkerimg());
            $content .= $storeimg[2].';'.$markerimg[2].';'.$item->getTitle().';'.$item->getAddress().';'.$item->getCountry().';'.$item->getState().';'.$item->getCity().';'.$item->getZipcode().';'.$item->getLatitude().';'.$item->getLongitude().';'.$item->getAddressDisplay().';'.$item->getWebsiteUrl().';'.$item->getPhone().';'."\n"; // ',pink-locator.png,Walmart Ottawa,1720 North Perry Street,US,OH,Ottawa,,41.02846,-84.04521,,http://www.walmart.com,(419) 523-6995,'."\n";
        }
        $this->_sendUploadResponse($fileName, $content);
    }
    public function exportXmlAction()
    {
        $fileName = 'storelocator.xml';
        //$content = $this->getLayout()->createBlock('cstorelocator/adminhtml_location_grid')->getXml();
        $collections = Mage::getModel('cstorelocator/location')->getCollection();
        $xml = '<?php xml version="1.0" encoding="UTF-8" ?>'."\n";
        $xml.= '<items>'."\n";
        $storeimg = '';
        $markerimg = '';
        foreach($collections as $item)
        {
            $storeimg = explode("/",$item->getStoreimg());
            $markerimg = explode("/",$item->getMarkerimg());
            $xml.= '<item>'."\n";
            $xml.= '<storeimg><![CDATA['.$storeimg[2].']]></storeimg>'."\n";
            $xml.= '<markerimg><![CDATA['.$markerimg[2].']]></markerimg>'."\n";
            $xml.= '<title><![CDATA['.$item->getTitle().']]></title>'."\n";
            $xml .= '<address><![CDATA['.$item->getAddress().']]></address>'."\n";
            $xml .= '<country><![CDATA['.$item->getCountry().']]></country>'."\n";
            $xml .= '<state><![CDATA['.$item->getState().']]></state>'."\n";
            $xml .= '<city><![CDATA['.$item->getCity().']]></city>'."\n";
            $xml .= '<zipcode><![CDATA['.$item->getZipcode().']]></zipcode>'."\n";
            $xml .= '<latitude><![CDATA['.$item->getLatitude().']]></latitude>'."\n";
            $xml .= '<longitude><![CDATA['.$item->getLongitude().']]></longitude>'."\n";
            $xml .= '<addressdisplay><![CDATA['.$item->getAddressDisplay().']]></addressdisplay>'."\n";
            $xml .= '<url><![CDATA['.$item->getWebsiteUrl().']]></url>'."\n";
            $xml .= '<phone><![CDATA['.$item->getPhone().']]></phone>'."\n"; 
            $xml.= '</item>'."\n";
        }
         $xml.= '</items>';
        $this->_sendUploadResponse($fileName, $xml);
    }
     protected function _sendUploadResponse($fileName, $content, $contentType='application/octet-stream')
    {
        $response = $this->getResponse();
        $response->setHeader('HTTP/1.1 200 OK','');
        $response->setHeader('Pragma', 'public', true);
        $response->setHeader('Cache-Control', 'must-revalidate, post-check=0, pre-check=0', true);
        $response->setHeader('Content-Disposition', 'attachment; filename='.$fileName);
        $response->setHeader('Last-Modified', date('r'));
        $response->setHeader('Accept-Ranges', 'bytes');
        $response->setHeader('Content-Length', strlen($content));
        $response->setHeader('Content-type', $contentType);
        $response->setBody($content);
        $response->sendResponse();
        die;
    }
    public function loadXML($Filepath)
    {
        $include_path = dirname(__FILE__);
        $path_to_PHP_ExcelReader = "read_xls/Excel/reader.php";
        require_once $path_to_PHP_ExcelReader;
        $data = new Spreadsheet_Excel_Reader();
        $data->setOutputEncoding('utf-8');
        $data->setUTFEncoder('mb');
        $index = 0;
        $data->setRowColOffset($index);
        $data->setDefaultFormat('%.2f');
        $data->setColumnFormat(4, '%.3f');
        $data->read($Filepath);
        return $data;
    }
}
