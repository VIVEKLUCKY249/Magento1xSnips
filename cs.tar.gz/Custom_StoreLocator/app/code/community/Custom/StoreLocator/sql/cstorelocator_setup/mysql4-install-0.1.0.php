<?php
/**
 * Custom_StoreLocator extension
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 * @category   Perception
 * @package    Custom_StoreLocator
 * @copyright  Copyright (c) 2008 Perception LLC
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

/**
 * @category   Perception
 * @package    Custom_StoreLocator
 * @author     Boris (Moshe) Gurevich <moshe@Perception.com>
 */

$installer = $this;
$installer->startSetup();

$installer->run("
DROP TABLE IF EXISTS {$this->getTable('cstorelocator_location')};
CREATE TABLE {$this->getTable('cstorelocator_location')} (
  `location_id` int(10) unsigned NOT NULL auto_increment,
  `storeimg` varchar(255) NOT NULL,
  `markerimg` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `country` varchar(255) NOT NULL,
  `zipcode`  varchar(255) NOT NULL,
  `state`  varchar(255) NOT NULL,
  `city`  varchar(255) NOT NULL,
  `latitude` decimal(15,10) NOT NULL,
  `longitude` decimal(15,10) NOT NULL,
  `address_display` text NOT NULL,
  `website_url` varchar(255) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `enable` tinyint(1) NOT NULL  DEFAULT '1',
  `product_types` varchar(255) NOT NULL,
  PRIMARY KEY  (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
");

$installer->endSetup();
