<?php
class Custom_StoreLocator_Model_Defaultcountry extends Mage_Core_Model_Config_Data
{
    protected function _beforeSave()
    {
        //get the value being saved
        $value = $this->getValue();
        
        $collection = Mage::getModel('cstorelocator/location')->getCollection()->addFieldToFilter(array('enable'), array('1'))->setOrder('country', 'ASC');
        $countryArr = $collection->getData();
        ## $countryArr = array_map("unserialize", array_unique(array_map("serialize", $countryArr)));
        foreach($countryArr as $country):
            $countryArr2[] = $country['country'];
        endforeach;
        $actualCountries = array_unique($countryArr2);

        if(count($actualCountries) > 1 && $value != 0) $isValid = false;
        else $isValid = true;
        
        if (!$isValid) {
            Mage::throwException(
                Mage::helper('cstorelocator')->__('There are multiple countries added already!!!')
            );
        }
    }
}
