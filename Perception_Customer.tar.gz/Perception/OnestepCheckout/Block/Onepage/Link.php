<?php
class Perception_OnestepCheckout_Block_Onepage_Link extends Mage_Core_Block_Template
{
    /**
     * Get this module data helper
     *
     * @return Perception_OnepageCheckout_Helper_Data Data helper
     */
    public function isOnestepCheckoutAllowed()
    {
        return $this->helper('onestepcheckout')->isOnestepCheckoutEnabled();
    }
    public function checkEnable()
    {
        return Mage::getSingleton('checkout/session')->getQuote()->validateMinimumAmount();
    }
    public function getOnestepCheckoutUrl()
    {
        $url = $this->getUrl('onestepcheckout', array(
            '_secure' => true
        ));
        return $url;
    }
}
