<?php
class Perception_OnestepCheckout_Helper_Url extends Mage_Checkout_Helper_Url
{
    public function getCheckoutUrl()
    {   
        
        $configValue = Mage::getStoreConfig(
                   'onestepcheckout/general/enabled',
                   Mage::app()->getStore()
               ); 
        if ($configValue) {
            return $this->_getUrl('onestepcheckout', array('_secure'=>true));
        } else {
            return $this->_getUrl('checkout/onepage', array('_secure'=>true));
        }
        
    }
}
