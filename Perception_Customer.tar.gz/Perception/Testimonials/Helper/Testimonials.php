<?php
class Perception_Testimonials_Helper_Testimonials extends Mage_Core_Helper_Abstract
{
    public function switchTemplateIf()
    {
	die('Ashok');
    }
}
