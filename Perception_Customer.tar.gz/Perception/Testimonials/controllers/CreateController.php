<?php
class Perception_Testimonials_CreateController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
		$this->loadLayout();     
		$this->_initLayoutMessages('customer/session');
		$this->renderLayout();
    }
	public function postAction()
	{		
		if ($data = $this->getRequest()->getPost()) {
			if(isset($_FILES['filename']['name']) && $_FILES['filename']['name'] != '') {
				try {
					$uploader = new Varien_File_Uploader('filename');					
	           		$uploader->setAllowedExtensions(array('jpg','jpeg','gif','png'));
					$uploader->setAllowRenameFiles(false);
					$uploader->setFilesDispersion(false);
					$path = Mage::getBaseDir('media') . DS . 'testimonials' . DS ;
					$uploader->save($path, $_FILES['filename']['name'] );
				}
				catch (Exception $e) {
				}
	  			$data['image'] = 'testimonials/'.$_FILES['filename']['name'];
			}
			
			/* Video upload */
			if(isset($_FILES['video']['name']) && $_FILES['video']['name'] != '') {
				try {
					$uploader = new Varien_File_Uploader('video');
	           		$uploader->setAllowedExtensions(array('mp4','flv','mpeg','vob'));
					$uploader->setAllowRenameFiles(false);
					$uploader->setFilesDispersion(false);
					$path = Mage::getBaseDir('media') . DS . 'testimonials' . DS . 'videos' . DS ;
					$uploader->save($path, $_FILES['video']['name'] );
					
				}
				catch (Exception $e) {
				}
	  			$data['video'] = 'testimonials/videos/'.$_FILES['video']['name'];
			} 
			
			$model = Mage::getModel('testimonials/testimonials');			
			$model->setData($data)->setId($this->getRequest()->getParam('id'));
			
			try {
				if ($model->getCreatedTime == NULL || $model->getUpdateTime() == NULL) {
					$model->setCreatedTime(now())
						->setUpdateTime(now());
				} else {
					$model->setUpdateTime(now());
				}	

				$model->save();
				Mage::getSingleton('customer/session')->addSuccess(Mage::helper('testimonials')->__('Your Testimonial was successfully submitted'));
				Mage::getSingleton('customer/session')->setFormData(false);
				$this->_redirect('*/*/');
				return;
            } catch (Exception $e) {
            }
        }
        Mage::getSingleton('customer/session')->addError(Mage::helper('testimonials')->__('Unable to find Testimonial to save'));
        $this->_redirect('*/*/');
	}
}