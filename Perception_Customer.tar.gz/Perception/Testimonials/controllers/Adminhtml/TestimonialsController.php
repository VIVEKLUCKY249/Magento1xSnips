<?php

class Perception_Testimonials_Adminhtml_TestimonialsController extends Mage_Adminhtml_Controller_action
{

	protected function _initAction() {
		$this->loadLayout()
			->_setActiveMenu('testimonials/items')
			->_addBreadcrumb(Mage::helper('adminhtml')->__('Testimonial Manager'), Mage::helper('adminhtml')->__('Testimonial Manager'));
		
		return $this;
	}   
 
	public function indexAction() {
		$this->_initAction()
			->renderLayout();
	}

	public function editAction() {
		$id     = $this->getRequest()->getParam('id');
		$model  = Mage::getModel('testimonials/testimonials')->load($id);

		if ($model->getId() || $id == 0) {
			$data = Mage::getSingleton('adminhtml/session')->getFormData(true);
			if (!empty($data)) {
				$model->setData($data);
			}

			Mage::register('testimonials_data', $model);

			$this->loadLayout();
			$this->_setActiveMenu('testimonials/items');

			$this->_addBreadcrumb(Mage::helper('adminhtml')->__('Testimonial Manager'), Mage::helper('adminhtml')->__('Testimonial Manager'));
			$this->_addBreadcrumb(Mage::helper('adminhtml')->__('Testimonial News'), Mage::helper('adminhtml')->__('Testimonial News'));

			$this->getLayout()->getBlock('head')->setCanLoadExtJs(true);
			
			if (Mage::getSingleton('testimonials/wysiwyg_config')->isEnabled()) {
				$this->getLayout()->getBlock('head')->setCanLoadTinyMce(true);
            }
			
			$this->_addContent($this->getLayout()->createBlock('testimonials/adminhtml_testimonials_edit'))
				->_addLeft($this->getLayout()->createBlock('testimonials/adminhtml_testimonials_edit_tabs'));

			$this->renderLayout();
		} else {
			Mage::getSingleton('adminhtml/session')->addError(Mage::helper('testimonials')->__('Testimonial does not exist'));
			$this->_redirect('*/*/');
		}
	}
 
	public function newAction() {
		$this->_forward('edit');
	}
 
	public function saveAction() {
		if ($data = $this->getRequest()->getPost()) {
			if(isset($_FILES['filename']['name']) && $_FILES['filename']['name'] != '') {
				try {
					$uploader = new Varien_File_Uploader('filename');					
					// Any extention would work
	           		$uploader->setAllowedExtensions(array('jpg','jpeg','gif','png'));
					$uploader->setAllowRenameFiles(false);
					$uploader->setFilesDispersion(false);
					$path = Mage::getBaseDir('media') . DS . 'testimonials' . DS ;
					$uploader->save($path, $_FILES['filename']['name'] );
					
				}
				catch (Exception $e) {
				}
	  			$data['image'] = 'testimonials/'.$_FILES['filename']['name'];
			} 
			else {
				if(isset($data['filename']['delete']) && $data['filename']['delete'] == 1) {
					$data['image'] = '';
				}
				else {
					unset($data['image']);
				}
			}
			
			if(isset($_FILES['video']['name']) && $_FILES['video']['name'] != '') {
				try {
					$uploader = new Varien_File_Uploader('video');					
					// Any extention would work
	           		$uploader->setAllowedExtensions(array('mp4','flv'));
					$uploader->setAllowRenameFiles(false);
					$uploader->setFilesDispersion(false);
					$path = Mage::getBaseDir('media') . DS . 'testimonials' . DS . 'videos' . DS ;
					$uploader->save($path, $_FILES['video']['name'] );
				}
				catch (Exception $e) {
				}
	  			$data['video'] = 'testimonials/videos/'.$_FILES['video']['name'];
				$data['urlvideo'] = '';
			} 
			else { 
				if($data['urlvideo'] != "") {
					$data['video'] = '';
				} 
			}
			
			$model = Mage::getModel('testimonials/testimonials');
			$model->setData($data)
				->setId($this->getRequest()->getParam('id'));
			try {
				if ($model->getCreatedTime == NULL || $model->getUpdateTime() == NULL) {
					$model->setCreatedTime(now())
						->setUpdateTime(now());
				} else {
					$model->setUpdateTime(now());
				}	

				$model->save();
			
				Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('testimonials')->__('Testimonial was successfully saved'));
				Mage::getSingleton('adminhtml/session')->setFormData(false);

				if ($this->getRequest()->getParam('back')) {
					$this->_redirect('*/*/edit', array('id' => $model->getId()));
					return;
				}
				$this->_redirect('*/*/');
				return;
            } catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
                Mage::getSingleton('adminhtml/session')->setFormData($data);
                $this->_redirect('*/*/edit', array('id' => $this->getRequest()->getParam('id')));
                return;
            }
        }
        Mage::getSingleton('adminhtml/session')->addError(Mage::helper('testimonials')->__('Unable to find Testimonial to save'));
        $this->_redirect('*/*/');
	}
 
	public function deleteAction() {
		if( $this->getRequest()->getParam('id') > 0 ) {
			try {
				$model = Mage::getModel('testimonials/testimonials');
				 
				$model->setId($this->getRequest()->getParam('id'))
					->delete();
					 
				Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('adminhtml')->__('Testimonial was successfully deleted'));
				$this->_redirect('*/*/');
			} catch (Exception $e) {
				Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
				$this->_redirect('*/*/edit', array('id' => $this->getRequest()->getParam('id')));
			}
		}
		$this->_redirect('*/*/');
	}

    public function massDeleteAction() {
        $testimonialsIds = $this->getRequest()->getParam('testimonials');
        if(!is_array($testimonialsIds)) {
			Mage::getSingleton('adminhtml/session')->addError(Mage::helper('adminhtml')->__('Please select Testimonial(s)'));
        } else {
            try {
                foreach ($testimonialsIds as $testimonialsId) {
                    $testimonials = Mage::getModel('testimonials/testimonials')->load($testimonialsId);
                    $testimonials->delete();
                }
                Mage::getSingleton('adminhtml/session')->addSuccess(
                    Mage::helper('adminhtml')->__(
                        'Total of %d record(s) were successfully deleted', count($testimonialsIds)
                    )
                );
            } catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
            }
        }
        $this->_redirect('*/*/index');
    }
	
    public function massStatusAction()
    {
        $testimonialsIds = $this->getRequest()->getParam('testimonials');
        if(!is_array($testimonialsIds)) {
            Mage::getSingleton('adminhtml/session')->addError($this->__('Please select Testimonial(s)'));
        } else {
            try {
                foreach ($testimonialsIds as $testimonialsId) {
                    $testimonials = Mage::getSingleton('testimonials/testimonials')
                        ->load($testimonialsId)
                        ->setStatus($this->getRequest()->getParam('status'))
                        ->setIsMassupdate(true)
                        ->save();
                }
                $this->_getSession()->addSuccess(
                    $this->__('Total of %d record(s) were successfully updated', count($testimonialsIds))
                );
            } catch (Exception $e) {
                $this->_getSession()->addError($e->getMessage());
            }
        }
        $this->_redirect('*/*/index');
    }
  
    public function exportCsvAction()
    {
        $fileName   = 'testimonials.csv';
        $content    = $this->getLayout()->createBlock('testimonials/adminhtml_testimonials_grid')
            ->getCsv();

        $this->_sendUploadResponse($fileName, $content);
    }

    public function exportXmlAction()
    {
        $fileName   = 'testimonials.xml';
        $content    = $this->getLayout()->createBlock('testimonials/adminhtml_testimonials_grid')
            ->getXml();

        $this->_sendUploadResponse($fileName, $content);
    }

    protected function _sendUploadResponse($fileName, $content, $contentType='application/octet-stream')
    {
        $response = $this->getResponse();
        $response->setHeader('HTTP/1.1 200 OK','');
        $response->setHeader('Pragma', 'public', true);
        $response->setHeader('Cache-Control', 'must-revalidate, post-check=0, pre-check=0', true);
        $response->setHeader('Content-Disposition', 'attachment; filename='.$fileName);
        $response->setHeader('Last-Modified', date('r'));
        $response->setHeader('Accept-Ranges', 'bytes');
        $response->setHeader('Content-Length', strlen($content));
        $response->setHeader('Content-type', $contentType);
        $response->setBody($content);
        $response->sendResponse();
        die;
    }
}