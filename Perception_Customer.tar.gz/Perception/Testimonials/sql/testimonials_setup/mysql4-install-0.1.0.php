<?php
$installer = $this;
$installer->startSetup();
$installer->run("

DROP TABLE IF EXISTS {$this->getTable('testimonials')};
CREATE TABLE {$this->getTable('testimonials')} (
  `testimonials_id` int(11) unsigned NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `author` varchar(255) NOT NULL default '',  
  `text` text NOT NULL default '',
  `image` varchar(255) NOT NULL default '',
  `video` varchar(255) NOT NULL default '',
  `urlvideo` varchar(255) NOT NULL default '',
  `status` smallint(6) NOT NULL default '0',
  `created_time` datetime NULL,
  `update_time` datetime NULL,
  PRIMARY KEY (`testimonials_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS {$this->getTable('testimonials_store')};
CREATE TABLE {$this->getTable('testimonials_store')} (
  `testimonials_id` smallint(5) NOT NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`testimonials_id`,`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='CMS Profiles to Stores';");

$installer->endSetup(); 