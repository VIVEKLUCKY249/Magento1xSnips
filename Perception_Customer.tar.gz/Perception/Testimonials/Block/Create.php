<?php
class Perception_Testimonials_Block_List_Create extends Mage_Core_Block_Abstract
{
	protected function _construct()
    {
        parent::_construct();
        $this->setTemplate('testimonials/create.phtml');
    }
}
?>