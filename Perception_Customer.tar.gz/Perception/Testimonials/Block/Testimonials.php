<?php
class Perception_Testimonials_Block_Testimonials extends Mage_Core_Block_Template
{
	public function _prepareLayout() {
		return parent::_prepareLayout();
    }
	public function getTestimonials() {
		if (!$this->hasData('testimonials')) {
			$this->setData('testimonials', Mage::registry('testimonials'));
        }
        return $this->getData('testimonials');
	}
}