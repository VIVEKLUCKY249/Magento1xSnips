<?php

class Perception_Testimonials_Block_Adminhtml_Testimonials_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
	protected function _prepareLayout() {
		parent::_prepareLayout();
		if (Mage::getSingleton('testimonials/wysiwyg_config')->isEnabled()) {
			$this->getLayout()->getBlock('head')->setCanLoadTinyMce(true);
		}
	}
	protected function _prepareForm() {
		$form = new Varien_Data_Form();
		$this->setForm($form);
		$fieldset = $form->addFieldset('testimonials_form', array('legend'=>Mage::helper('testimonials')->__('Testimonial Information')));
		
		$fieldset->addField('title', 'text', array(
			'label'     => Mage::helper('testimonials')->__('Title'),
			'class'     => 'required-entry',
			'required'  => true,
			'name'      => 'title',
		));

		$fieldset->addField('author', 'text', array(
			'label'     => Mage::helper('testimonials')->__('Author'),
			'class'     => 'required-entry',
			'required'  => true,
			'name'      => 'author',
		));

		$fieldset->addField('image', 'image', array(
			'label'     => Mage::helper('testimonials')->__('Image'),
			'required'  => false,
			'name'      => 'filename',
		));

		$fieldset->addField('radio-control', 'radios', array(
			'label'     => Mage::helper('testimonials')->__('Video'),
			'name'      => 'client-video',
			'onclick' => "",
			'onchange' => "",
			'value'  => '0',
			'values' => array(
				array('value'=>'1','label'=>'Video', 'checked' => true),
				array('value'=>'2','label'=>'URL'),
			),
			'disabled' => false,
			'readonly' => false,
			'after_element_html' => '<small></small>',
			'tabindex' => 1,
			'checked'	 => true,
		));

		$fieldset->addField('video', 'file', array(
			'label'     => Mage::helper('testimonials')->__('Upload Video'),
			'name'	  => 'video',
			'required'  => false,
			'after_element_html' => '<label>'.substr(Mage::registry('testimonials_data')->getData('video'),20).'</label><br /><label><small>Supported file formats (.flv, .mp4, .vob, .mov, .mp4v, .f4v)</small></label>',
			'class'		=> 'upload-control'
		));	

		$fieldset->addField('urlvideo', 'text', array(
			'label'     => Mage::helper('testimonials')->__('Video URL'),
			'name'	    => 'urlvideo',
			'required'  => false,
			'class'		=> 'url-control validate-url',
			'after_element_html' => '<br /><label><small>Supported URLs (You Tube /Blip.tv/ Break /Google)</small></label>',
		));

		if (!Mage::app()->isSingleStoreMode()) {
			$fieldset->addField('store_id', 'multiselect', array(
				'name'      => 'stores[]',
				'label'     => Mage::helper('cms')->__('Store View'),
				'title'     => Mage::helper('cms')->__('Store View'),
				'required'  => true,
				'values'    => Mage::getSingleton('adminhtml/system_store')->getStoreValuesForForm(false, true),
				'disabled'  => $isElementDisabled
			));
		}
		else {
			$fieldset->addField('store_id', 'hidden', array(
				'name'      => 'stores[]',
				'value'     => Mage::app()->getStore(true)->getId()
			));
		}

		$fieldset->addField('status', 'select', array(
			'label' => Mage::helper('testimonials')->__('Status'),
			'name' => 'status',
			'values' => array(
				array(
					'value' => 1,
					'label' => Mage::helper('testimonials')->__('Approved'),
				),
				array(
					'value' => 2,
					'label' => Mage::helper('testimonials')->__('Disapproved'),
				),
				
				array(
					'value' => 3,
					'label' => Mage::helper('testimonials')->__('Pending'),
				),
			),
		));

		$fieldset->addField('text', 'editor', array(
			'name'      => 'text',
			'label'     => Mage::helper('testimonials')->__('Content'),
			'title'     => Mage::helper('testimonials')->__('Content'),
			'style'     => 'width:700px; height:500px;',
			'wysiwyg'   => true,
			'required'  => true,
			'config'    => Mage::getSingleton('testimonials/wysiwyg_config')->getConfig()
		));

		if ( Mage::getSingleton('adminhtml/session')->getTestimonialsData() ) {
			$form->setValues(Mage::getSingleton('adminhtml/session')->getTestimonialsData());
			Mage::getSingleton('adminhtml/session')->setTestimonialsData(null);
		} 
		elseif ( Mage::registry('testimonials_data') ) {
			$form->setValues(Mage::registry('testimonials_data')->getData());
		}
		return parent::_prepareForm();
	}
}
?>
<script type="text/javascript">
	jQuery.noConflict();
	jQuery(document).ready(function(){
		jQuery(".upload-control").parent('td').parent('tr').hide();
		jQuery(".url-control").parent('td').parent('tr').hide();
		<?php if(substr(Mage::registry('testimonials_data')->getData('video'),0,4) == 'test') : ?>
			jQuery('#radio-control1').attr('checked','checked');
		<?php elseif(substr(Mage::registry('testimonials_data')->getData('urlvideo'),0,4) == 'http') : ?>
			jQuery('#radio-control2').attr('checked','checked');
		<?php endif; ?>
		jQuery("#radio-control1").click(function () {
			if (jQuery(this).attr("checked")) { jQuery(".upload-control").parent('td').parent('tr').show(); jQuery(".url-control").parent('td').parent('tr').hide(); }
		});
		jQuery("#radio-control2").click(function () {
			if (jQuery(this).attr("checked")) { jQuery(".upload-control").parent('td').parent('tr').hide(); jQuery(".url-control").parent('td').parent('tr').show(); }
		});
		if (jQuery('#radio-control1').attr("checked")) { jQuery(".upload-control").parent('td').parent('tr').show(); }
		if (jQuery('#radio-control2').attr("checked")) { jQuery(".url-control").parent('td').parent('tr').show(); jQuery(".url-control").attr('value','<?php echo Mage::registry('testimonials_data')->getData('urlvideo') ?>'); }
	});
</script>
