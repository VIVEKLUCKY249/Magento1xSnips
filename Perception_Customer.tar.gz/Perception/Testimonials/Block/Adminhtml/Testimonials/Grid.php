<?php

class Perception_Testimonials_Block_Adminhtml_Testimonials_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
  public function __construct()
  {
      parent::__construct();
      $this->setId('testimonialsGrid');
      $this->setDefaultSort('testimonials_id');
      $this->setDefaultDir('ASC');
      $this->setSaveParametersInSession(true);
  }

  protected function _prepareCollection()
  {
      $collection = Mage::getModel('testimonials/testimonials')->getCollection();
      $this->setCollection($collection);
      return parent::_prepareCollection();
  }

  protected function _prepareColumns()
  {
      $this->addColumn('testimonials_id', array(
          'header'    => Mage::helper('testimonials')->__('ID'),
          'align'     =>'center',
          'width'     => '50px',
          'index'     => 'testimonials_id',
      ));
		
	$this->addColumn('image', array(
		'header'=>Mage::helper('testimonials')->__('Image'),
        'filter'=>false,
        'index'=>'image',
        'align' => 'left',
        'width'     => '50px',
	    'renderer'  => 'testimonials/adminhtml_grid_renderer_image',
		)); 
		
      $this->addColumn('title', array(
          'header'    => Mage::helper('testimonials')->__('Title'),
          'align'     =>'left',
          'index'     => 'title',
      ));
	  
      $this->addColumn('author', array(
          'header'    => Mage::helper('testimonials')->__('Author'),
          'align'     =>'left',
	  'width'     => '100px',
          'index'     => 'author',
      ));

	  if (!Mage::app()->isSingleStoreMode()) {
		$this->addColumn('store_id', array(
			'header'        => Mage::helper('testimonials')->__('Store View'),
			'index'         => 'store_id',
			'type'          => 'store',
			'store_all'     => true,
			'store_view'    => true,
			'sortable'      => false,
			'width'			=> '120px',
			'filter_condition_callback'
							=> array($this, '_filterStoreCondition'),
		));
	 }
	   
	  $this->addColumn('created_time', array(
          'header'    => Mage::helper('testimonials')->__('Posted Date'),
          'align'     =>'left',
		  'width'     => '150px',
          'index'     => 'created_time',
      ));
	  
      $this->addColumn('status', array(
          'header'    => Mage::helper('testimonials')->__('Status'),
          'align'     => 'left',
          'width'     => '80px',
          'index'     => 'status',
          'type'      => 'options',
          'options'   => array(
              1 => 'Enabled',
              2 => 'Disabled',
			  3 => 'Pending',
          ),
      ));
	  
        $this->addColumn('action',
            array(
                'header'    =>  Mage::helper('testimonials')->__('Action'),
                'width'     => '100',
                'type'      => 'action',
                'getter'    => 'getId',
                'actions'   => array(
                    array(
                        'caption'   => Mage::helper('testimonials')->__('Edit'),
                        'url'       => array('base'=> '*/*/edit'),
                        'field'     => 'id'
                    )
                ),
                'filter'    => false,
                'sortable'  => false,
                'index'     => 'stores',
                'is_system' => true,
        ));
		
		$this->addExportType('*/*/exportCsv', Mage::helper('testimonials')->__('CSV'));
		$this->addExportType('*/*/exportXml', Mage::helper('testimonials')->__('XML'));
	  
      return parent::_prepareColumns();
  }

    protected function _prepareMassaction()
    {
        $this->setMassactionIdField('testimonials_id');
        $this->getMassactionBlock()->setFormFieldName('testimonials');

        $this->getMassactionBlock()->addItem('delete', array(
             'label'    => Mage::helper('testimonials')->__('Delete'),
             'url'      => $this->getUrl('*/*/massDelete'),
             'confirm'  => Mage::helper('testimonials')->__('Are you sure?')
        ));

        return $this;
    }
	
	protected function _afterLoadCollection() {
        $this->getCollection()->walk('afterLoad');
        parent::_afterLoadCollection();
    }
	
	protected function _filterStoreCondition($collection, $column) {
		if (!$value = $column->getFilter()->getValue()) {
            return;
        }
        $this->getCollection()->addStoreFilter($value);
    }
	
	public function getRowUrl($row) {
		return $this->getUrl('*/*/edit', array('id' => $row->getId()));
	}
}
