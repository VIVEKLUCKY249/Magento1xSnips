<?php

class Perception_Testimonials_Block_Adminhtml_Grid_Renderer_Video extends Mage_Adminhtml_Block_Widget_Grid_Column_Renderer_Abstract
{
    public function render(Varien_Object $row)
    {
	    if($row->getVideo() == ""){
            return "";
        }
        else{
	    return "<embed src='".Mage::getBaseUrl("media").$row->getVideo()."' autostart='false' />";
        }
    }
} 
