<?php
class Perception_Testimonials_Block_Subscribe extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
     public function getSubscribe()     
     { 
        if (!$this->hasData('subscribe')) {
            $this->setData('subscribe', Mage::registry('subscribe'));
        }
        return $this->getData('subscribe');
        
    }
}