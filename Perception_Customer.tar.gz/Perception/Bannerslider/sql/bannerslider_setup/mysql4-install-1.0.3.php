<?php
$installer = $this;
$installer->startSetup();

$installer->run("

DROP TABLE IF EXISTS {$this->getTable('bannerslider')};
CREATE TABLE {$this->getTable('bannerslider')} (
  `bannerslider_id` int(11) unsigned NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `image_thumb` varchar(255) NOT NULL default '',
  `filename` varchar(255) NOT NULL default '',
  `text` text NULL,
  `sorting_order` int(11) NOT NULL default '0',
  `status` smallint(6) NOT NULL default '0',
  `weblink` varchar(255) NULL,
  `created_time` datetime NULL,
  `update_time` datetime NULL,
  PRIMARY KEY (`bannerslider_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS {$this->getTable('bannerslider_store')};
CREATE TABLE {$this->getTable('bannerslider_store')} (
  `bannerslider_id` smallint(6) NOT NULL,
  `store_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`bannerslider_id`,`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='CMS Profiles to Stores';");

$installer->endSetup(); 