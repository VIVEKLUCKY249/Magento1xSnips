<?php

class Perception_Bannerslider_Block_Adminhtml_Bannerslider_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
  protected function _prepareForm()
  {
      $form = new Varien_Data_Form();
      $this->setForm($form);
      
      $fieldset = $form->addFieldset('bannerslider_form', array('legend'=>Mage::helper('bannerslider')->__('Item information')));
     
      $fieldset->addField('title', 'text', array(
          'label'     => Mage::helper('bannerslider')->__('Title'),
          'class'     => 'required-entry',
          'required'  => true,
          'name'      => 'title',
      ));

      $fieldset->addField('filename', 'image', array(
          'label'     => Mage::helper('bannerslider')->__('Photo image'),
          'required'  => false,
          'name'      => 'filename',
	  ));
	  
  	  /**
         * Check is single store mode
         */
        if (!Mage::app()->isSingleStoreMode()) {
            $fieldset->addField('store_id', 'multiselect', array(
                'name'      => 'stores[]',
                'label'     => Mage::helper('cms')->__('Store View'),
                'title'     => Mage::helper('cms')->__('Store View'),
                'required'  => true,
                'values'    => Mage::getSingleton('adminhtml/system_store')->getStoreValuesForForm(false, true),
                'disabled'  => $isElementDisabled
            ));
        }
        
	  else {
	   $fieldset->addField('store_id', 'hidden', array(
	           'name'      => 'stores[]',
	           'value'     => Mage::app()->getStore(true)->getId()
	   ));
	   $model->setStoreId(Mage::app()->getStore(true)->getId());
	  }
	  
	  
      $fieldset->addField('status', 'select', array(
          'label'     => Mage::helper('bannerslider')->__('Status'),
          'name'      => 'status',
          'values'    => array(
              array(
                  'value'     => 1,
                  'label'     => Mage::helper('bannerslider')->__('Enabled'),
              ),

              array(
                  'value'     => 2,
                  'label'     => Mage::helper('bannerslider')->__('Disabled'),
              ),
          ),
      ));
      
	 $fieldset->addField('sorting_order', 'text', array(
          'label'     => Mage::helper('bannerslider')->__('Sorting Order'),
          'required'  => false,
		  'style'     => 'width:50px;',
          'name'      => 'sorting_order',
      ));
   
     $fieldset->addField('text', 'editor', array(
	'name'      => 'text',
	'label'     => Mage::helper('bannerslider')->__('Content'),
	'title'     => Mage::helper('bannerslider')->__('Content'),
	'style'     => 'width:700px; height:500px;',
	'wysiwyg'   => true,
	'required'  => true,
	'config'    => Mage::getSingleton('bannerslider/wysiwyg_config')->getConfig() 
      ));
      
      if ( Mage::getSingleton('adminhtml/session')->getBannerSliderData() )
      {
          $form->setValues(Mage::getSingleton('adminhtml/session')->getBannerSliderData());
          Mage::getSingleton('adminhtml/session')->setBannerSliderData(null);
      } elseif ( Mage::registry('bannerslider_data') ) {
          $form->setValues(Mage::registry('bannerslider_data')->getData());
      }
      return parent::_prepareForm();
  }
}
