<?php
class Perception_Defaultattributes_Model_Observer
{
	public function checkRemember_default_attributes($observer)
	{
		$product = $observer->getEvent()->getProduct();
		//print_r($product->getData());
		//$product->setAttributeSetId(4);
		//$product->setStatus(1);
		$product->setTaxClassId(2);
	}
}
