<?php
class Custom_StoreLocator_Model_Observer extends Varien_Event_Observer
{
	public function validateDefaultCountry($observer) {
		//echo "<pre/>";print_r($observer->getEvent());die;
	}
}
