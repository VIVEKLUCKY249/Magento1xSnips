var markerVisitor = false;
var markers = new Array();
var map;
function initialize(){
	bounds = new google.maps.LatLngBounds();
        var mapOption = {zoom: 17, mapTypeId: google.maps.MapTypeId.ROADMAP, mapTypeControl:true, zoomControl : true};
	map = new google.maps.Map(document.getElementById('map'), mapOption);
        direction = new google.maps.DirectionsRenderer({
        map                 : map,
        panel               : document.getElementById('panel'),
        suppressMarkers     : true
    });
    autocomplete = new google.maps.places.Autocomplete($("address"));
    google.maps.event.addListener(autocomplete, 'place_changed', autocompleteCallback);

    infoWindow = new google.maps.InfoWindow();
	initGeoloc();
	initStores();
         map.setZoom(16);  
}

function getItineraire(lat, lng ){
    var destination = new google.maps.LatLng(lat, lng);
    if(markerVisitor){
    var origin = markerVisitor.getPosition();
    var request = {
        origin      : origin,
        destination : destination,
        travelMode  : google.maps.DirectionsTravelMode.DRIVING
    }
    var directionsService = new google.maps.DirectionsService();
    directionsService.route(request, function(response, status){
        if(status == google.maps.DirectionsStatus.OK){
            direction.setDirections(response);
        }
    });
    }

}

function getMyLatLng(){
    if(navigator.geolocation){
        navigator.geolocation.getCurrentPosition(function(position){
            var latlng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
        }, erreurPosition);
        return latlng;
    }
}



function initGeoloc(){
	if(apiSensor){
	    if(navigator.geolocation) {
	        survId = navigator.geolocation.getCurrentPosition(maPosition,erreurPosition);
	    }
	}
}

function maPosition(position) {
    latlng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
    markerPosition(latlng);
}

function erreurPosition(error) {
    var info = "Error geolocation : ";
    switch(error.code) {
        case error.TIMEOUT:
            info += "Timeout!";
            break;
        case error.PERMISSION_DENIED:
            info += "You have not given permission";
            break;
        case error.POSITION_UNAVAILABLE:
            info += "The position could not be determined";
            break;
        case error.UNKNOWN_ERROR:
            info += "unknown error";
            break;
    }
}

function updatestores()
{ 
        var countryId = document.getElementById('country').value;
        var stateId = document.getElementById('state').value;
        var cityId = document.getElementById('city').value;
        var zipcodeval = document.getElementById('store_zipcode').value;
        var lat,lng;
        var latlong = '';
     
        
        var LatLngList = new Array ();
        var LatLngzip = new Array();
        
         
      for(i=0; i< stores.items.length; i++)
        {
            if(countryId != 0)
            { 
                if(stores.items[i].country_id != countryId)
                {
                  markers[i].setMap(null);
                }
                else
                {
                   markers[i].setMap(map);
                   
                   if(stateId == 0)
                   {
                     LatLngList.push(new google.maps.LatLng(stores.items[i].lat,stores.items[i].long));  
                   }
                
                }
            }
            
            if(stateId != 0)
            { 
                if(stores.items[i].state != stateId)
                {
                  markers[i].setMap(null);
                }
                else
                {
                   markers[i].setMap(map);
                   if(cityId == 0)
                   {    
                     LatLngList.push(new google.maps.LatLng(stores.items[i].lat,stores.items[i].long));
                   }
                }
            }
            
            if(cityId != 0)
            { 
                if(stores.items[i].city != cityId)
                {
                  markers[i].setMap(null);
                }
                else
                {
                   markers[i].setMap(map); 
                  LatLngList.push(new google.maps.LatLng(stores.items[i].lat,stores.items[i].long));
                }
            }
            
            if(countryId == 0)
            {
                markers[i].setMap(map);
                LatLngList.push(new google.maps.LatLng(stores.items[i].lat,stores.items[i].long));
            }
            
            if(zipcodeval != '')
            {
               if(stores.items[i].zipcode != zipcodeval)
                {
                  markers[i].setMap(null);
                }
                else
                {
                   markers[i].setMap(map);
                   LatLngzip.push(new google.maps.LatLng(stores.items[i].lat,stores.items[i].long));
                }     
            }
        }
        

if(LatLngzip.length > 0)
{
   LatLngList = LatLngzip;
}    

var boundsmap = new google.maps.LatLngBounds ();
for (var i = 0, LtLgLen = LatLngList.length; i < LtLgLen; i++) {
  boundsmap.extend (LatLngList[i]);
}
map.fitBounds (boundsmap);
map.panToBounds(boundsmap);
    

}

function initStores(){
	
        
       for(i=0; i< stores.items.length; i++){
        
            	var latLng =  new google.maps.LatLng(stores.items[i].lat, stores.items[i].long);
		bounds.extend(latLng);
		if(stores.items[i].marker){
			var imgMarker = new google.maps.MarkerImage(pathMarker+stores.items[i].marker,null,null,null,new google.maps.Size(22, 41));
		}else{
			if(defaultMarker){
				var imgMarker = new google.maps.MarkerImage(pathMarker+'theme/'+defaultMarker,null,null,null,new google.maps.Size(22, 41));
			}else{
                            	var imgMarker = new google.maps.MarkerImage(pathMarker+'storelocator/map.png',null,null,null,new google.maps.Size(22, 41));
			}
		}
	    markers[i] = new google.maps.Marker({position: latLng, icon: imgMarker,map: map, store: stores.items[i]});
	    google.maps.event.addListener(markers[i], 'click', openWindowInfo);
            
                $('store'+stores.items[i].entity_id).observe('click', openWindowInfo.bind(markers[i]));
           
	}
    map.fitBounds(bounds);
    map.panToBounds(bounds);
    
}

function openWindowInfo(){
    var showAdd = this.store.address;
    if(!this.store.image){
        this.store.image = defaultImage;
    }

    if(this.store.displayaddress != '')
     {
        showAdd = this.store.displayaddress;
     }
     
     var city = this.store.city.split("_").join("&nbsp;");
    
	var content = 	'<div class="map-store-info"><div class="map-store-img"><img src="'+this.store.image +'" alt="'+this.store.name+'"  width="70"  /></div><div class="map-store-detail"><h3>' + this.store.name + '</h3>'
     + '<span class="store-address">' + showAdd + '</span>'+'<br>'
     + city +' <br>'+ this.store.country_id + '<br>';


    if(this.store.phone){
        content += '<span class="store-contact"> Phone : '+ this.store.phone + '</span>'
    }

    
    if(markerVisitor && directionEnable){
        content += '<span onclick="getItineraire('+this.store.lat+','+ this.store.long+')" class="span-geoloc">'+estimateDirectionLabel+'</span></div></div>';
    }
content += "</div></div>";
    infoWindow.setContent(content);
    infoWindow.open(map,this); 
}

function moveToLocation(lat, lng){
    var center = new google.maps.LatLng(41.6166700000, -83.6601100000);
    var bounds = new google.maps.LatLngBounds();
}

function autocompleteCallback(){
    var place = this.getPlace();
    position = place.geometry.location;
    var latLng = new google.maps.LatLng(position.lat(), position.lng());
    markerPosition(latLng);
}

function markerPosition(latlng){
    bounds.extend(latlng);
    if(markerVisitor){
        markerVisitor.setPosition(latlng);
    }else{
        markerVisitor = new google.maps.Marker({
            position: latlng,
            map: map,
            title:"You are here"
        });
    }
    map.panTo(latlng);
    map.setZoom(12);
}